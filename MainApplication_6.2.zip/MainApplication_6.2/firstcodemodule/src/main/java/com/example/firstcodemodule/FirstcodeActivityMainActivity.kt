package com.example.firstcodemodule

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.alibaba.android.arouter.facade.annotation.Route
import com.example.basemodule.base.BaseActivity


@Route(path = "/firstcode/main")
class FirstcodeActivityMainActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.firstcode_activity_main)
        setTitle("第一行代码")
    }

    override fun getLayoutId(): Int {
        return R.layout.firstcode_activity_main
    }

    override fun afterCreate(savedInstanceState: Bundle?) {
    }
}
