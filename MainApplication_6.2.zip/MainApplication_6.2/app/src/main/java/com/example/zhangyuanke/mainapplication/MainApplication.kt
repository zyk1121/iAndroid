package com.example.zhangyuanke.mainapplication

import android.app.Application
import android.util.Log
import com.alibaba.android.arouter.launcher.ARouter
import java.util.logging.Handler

/**
 * Created by zhangyuanke on 2018/6/2.
 */

class MainApplication: Application() {

    private var mContext: MainApplication? = null

    private var mMainThreadHandler: Handler? = null

    override fun onCreate() {
        super.onCreate()

        mContext = this
//        mMainThreadHandler = android.os.Handler()

        ARouter.openLog()
        ARouter.openDebug()
        ARouter.init(this)

        // 设置导航栏状态颜色


        Log.v("puny","MainApplication 应用程序启动了...")
    }

    fun getApplication(): MainApplication {
        return mContext!!
    }

    fun getMainThreadHandler(): Handler {
        return mMainThreadHandler!!
    }
}