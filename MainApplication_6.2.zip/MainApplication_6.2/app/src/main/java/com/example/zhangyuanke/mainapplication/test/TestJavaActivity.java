package com.example.zhangyuanke.mainapplication.test;

import android.app.Activity;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.example.zhangyuanke.mainapplication.R;

/**
 * Created by zhangyuanke on 2018/6/2.
 */
@Route(path = "/main/testjava")
public class TestJavaActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_test_java);
    }
}
