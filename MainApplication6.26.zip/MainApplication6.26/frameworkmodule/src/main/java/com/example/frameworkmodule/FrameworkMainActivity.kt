package com.example.frameworkmodule

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.basemodule.base.BaseActivity

class FrameworkMainActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_framework_main)
        setTitle("Android架构")
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_framework_main
    }

    override fun afterCreate(savedInstanceState: Bundle?) {
    }
}
