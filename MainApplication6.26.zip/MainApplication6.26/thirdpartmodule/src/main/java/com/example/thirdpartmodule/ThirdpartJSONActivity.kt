package com.example.thirdpartmodule

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import com.alibaba.fastjson.JSON
import com.example.basemodule.base.BaseActivity
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONArray
import org.json.JSONObject


// https://blog.csdn.net/burn_yourself/article/details/51313940
//https://blog.csdn.net/axuanqq/article/details/51441590
class ThirdpartJSONActivity : BaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_thirdpart_json
    }

    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_thirdpart_json)
        setTitle("JSON解析")
    }

    public fun btnClick(view:View) {
//        Toast.makeText(this,"btn:" + view.id,Toast.LENGTH_SHORT).show()
//        testGson()
        testFastJson()
    }

    fun testGson(){
        test7()
    }

    fun test9()
    {
        /*
        11.支持泛型，
        对于一般的json解析都有固定格式，如code，message，data，当我们需要解析的只有data层但又不知到data层是什么时，可以定义泛型类
        public class Result<T> {
            public int code;
            public String message;
            public T data;
        }
        解析data层：
        //不再重复定义Result类
        (data层为user对象)
        Type userType = new TypeToken<Result<User>>(){}.getType();
        Result<User> userResult = gson.fromJson(json,userType);
        User user = userResult.data;
        (data层为List<user>)
        Type userListType = new TypeToken<Result<List<User>>>(){}.getType();
        Result<List<User>> userListResult = gson.fromJson(json,userListType);
        List<User> users = userListResult.data;
        */
    }

    fun test8()
    {
        /*
        10. @SerializedName 注解

        值得注意的是，当大家将 json 串解析成 对象的时候，对象中的属性一定要与 json串中的 属性完全一样，如

        String json="{\"name\":\"小明\",\"age\":\"23\"}"时，那么person对象的属性名称必须为 name 和 age，若person中的属性 命名为 Name，Age或者其他在的名称，gson则解析不出来，必须和  json串中的 属性完全一样！！！谨记啊，同学们！

        最新：如果不想自定义的类和json数据相对应，你需要借助 @SerializedName 注解，
        如，String json="{\"name\":\"小明\",\"age\":\"23\"}，你的类中的name属性为 String personName；则你需要这样写
        @SerializedName("name");
        private String personName;来转化json和你实体类间的关系，注解@SerializedName("name");中的name必须和json中的name一样
        */

    }

    fun test7()
    {
        val json = "{\"name\":\"小明\",\"age\":\"23\"}"
        val gson = Gson()
        val listType = object : TypeToken<Map<String, String>>() {

        }.type//TypeToken内的泛型就是Json数据中的类型
        val map = gson.fromJson<Map<String, String>>(json, listType)

        Log.v("puny", "==name==" + map["name"])
        Log.v("puny", "==age==" + map["age"])
    }

    // 若json是对象，且其中含list，则按层解析
    fun test6()
    {
        val json = "{\"name\":\"小明\",\"age\":\"23\",\"books\":[{\"mBookName\":\"故事1\",\"mBookprice\":\"23\"},{\"mBookName\":\"故事2\",\"mBookprice\":\"25\"}]}"
        val gson = Gson()

        val p1 = gson.fromJson(json, Person::class.java)

        Log.v("puny", "p.getAge()" + p1.age)
        Log.v("puny", "p.getName()" + p1.name!!)
        Log.v("puny", "p.getBooks()" + gson.toJson(p1.books))

        val listType = object : TypeToken<ArrayList<Book>>() {

        }.type//TypeToken内的泛型就是Json数据中的类型
        val books = gson.fromJson<ArrayList<Book>>(gson.toJson(p1.books), listType)
        for (b in books) {
            Log.v("puny", "b.getmBookName()" + b.mBookName)
            Log.v("puny", "b.getmBookprice()" + b.mBookprice)
        }
    }

    fun test5()
    {
        // 若 json 是 数组形式，则借助 TypeToken获取泛型参数的类型 进行转换
        val json = "[{\"name\":\"小明\",\"age\":\"23\"},{\"name\":\"小芳\",\"age\":\"22\"}]"
        val gosn = Gson()
        //使用Type类，取得相应类型对象的class属性
        val listType = object : TypeToken<ArrayList<Person>>() {

        }.type//TypeToken内的泛型就是Json数据中的类型
        val persons = gosn.fromJson<ArrayList<Person>>(json, listType)
        for (p in persons) {
            Log.v("puny", "p.getAge()" + p.age)
            Log.v("puny", "p.getName()" + p.name!!)
        }
    }

    fun test4()
    {
        val json = "{\"name\":\"小明\",\"age\":\"23\"}"
        val gosn = Gson()
        val p = gosn.fromJson(json, Person::class.java)
        Log.v("puny", "p.getAge()=" + p.age)
        Log.v("puny", "p.getName()=" + p.name!!)
    }

    fun test3()
    {
        val map = HashMap<String, String>()
        map["name"] = "小芳"
        map["like"] = "reading"
        val gson = Gson()
        val json = gson.toJson(map)
        Log.v("puny", "map to json===$json")
    }
    fun test1() {
        val mPerson= Person()
        mPerson.age = 23
        mPerson.name = "小明"

        val gson = Gson()

        val personStr = gson.toJson(mPerson)

        Log.v("puny","personStr="+personStr)
    }

    fun test2() {
        var persons:MutableList<Person> = mutableListOf()
        for (i in 0..3) {
            // 0 1 2 3
            val mPerson= Person()
            mPerson.age = 23
            mPerson.name = "小明" + i
            persons.add(mPerson)
        }

        val gson = Gson()

        val personStr = gson.toJson(persons)

        Log.v("puny","list person="+personStr)
    }

    /*常用api
1. 将对象序列化成json字符串

String com.alibaba.fastjson.JSON.toJSONString(Object object)

2. 将json字符串反序列化成对象

<T> Project com.alibaba.fastjson.JSON.parseObject(String text, Class<T> clazz)

3. 将json字符串反序列化成JSON对象

JSONObject com.alibaba.fastjson.JSON.parseObject(String text)

4.根据key 得到json中的json数组

JSONArray com.alibaba.fastjson.JSONObject.getJSONArray(String key)

5. 根据下标拿到json数组的json对象

JSONObject com.alibaba.fastjson.JSONArray.getJSONObject(int index)

6.. 根据key拿到json的字符串值

String com.alibaba.fastjson.JSONObject.getString(String key)

7. 根据key拿到json的int值

int com.alibaba.fastjson.JSONObject.getIntValue(String key)

8. 根据key拿到json的boolean值

boolean com.alibaba.fastjson.JSONObject.getBooleanValue(String key)
*/

    // https://segmentfault.com/a/1190000011212806
    fun testFastJson() {
        // https://segmentfault.com/a/1190000011212806
        testfast1()
    }

    fun testfast6()
    {
        /*
        * /**
 * 复杂json格式字符串到JavaBean_obj的转换
 */
@Test
public void testComplexJSONStrToJavaBean(){

    //第一种方式,使用TypeReference<T>类,由于其构造方法使用protected进行修饰,故创建其子类
    Teacher teacher = JSONObject.parseObject(COMPLEX_JSON_STR, new TypeReference<Teacher>() {});
    System.out.println(teacher);

    //第二种方式,使用Gson思想
    Teacher teacher1 = JSONObject.parseObject(COMPLEX_JSON_STR, Teacher.class);
    System.out.println(teacher1);
}

/**
 * 复杂JavaBean_obj到json格式字符串的转换
 */
@Test
public void testJavaBeanToComplexJSONStr(){

    //已知复杂JavaBean_obj
    Teacher teacher = JSONObject.parseObject(COMPLEX_JSON_STR, new TypeReference<Teacher>() {});
    String jsonString = JSONObject.toJSONString(teacher);
    System.out.println(jsonString);
}
*/
    }

    fun testfast5()
    {
        /*
        //第一种方式
        val jsonArray = JSONArray.parseArray(JSON_ARRAY_STR)

        //遍历JSONArray
        val students = ArrayList<Student>()
        var student: Student? = null
        for (`object` in jsonArray) {

            val jsonObjectone = `object` as JSONObject
            val studentName = jsonObjectone.getString("studentName")
            val studentAge = jsonObjectone.getInteger("studentAge")

            student = Student(studentName, studentAge)
            students.add(student)
        }

        println("students:  $students")


        //第二种方式,使用TypeReference<T>类,由于其构造方法使用protected进行修饰,故创建其子类
        val studentList = JSONArray.parseObject(JSON_ARRAY_STR, object : TypeReference<ArrayList<Student>>() {

        })
        println("studentList:  $studentList")

        //第三种方式,使用Gson的思想
        val studentList1 = JSONArray.parseArray(JSON_ARRAY_STR, Student::class.java)
        println("studentList1:  $studentList1")
        */

    }

    fun testfast4()
    {
//        val student = Student("lily", 12)
//        val jsonString = JSONObject.toJSONString(student)
//        println(jsonString)
    }

    fun testfast3()
    {
        val JSON_OBJ_STR = "{\"studentName\":\"lily\",\"studentAge\":12}"
        //第一种方式
        val jsonObject = JSONObject(JSON_OBJ_STR)

        val studentName = jsonObject.getString("studentName")
        val studentAge = jsonObject.getInt("studentAge")

        //Student student = new Student(studentName, studentAge);

        //第二种方式,使用TypeReference<T>类,由于其构造方法使用protected进行修饰,故创建其子类
        //Student student = JSONObject.parseObject(JSON_OBJ_STR, new TypeReference<Student>() {});

        //第三种方式,使用Gson的思想
//        JSONObject(JSON_OBJ_STR)
//        val student = JSONObject(JSON_OBJ_STR, Student::class.java)

//        System.out.println(student)
    }

    fun testfast2()
    {
        val JSON_ARRAY_STR =  "[{\"studentName\":\"lily\",\"studentAge\":12},{\"studentName\":\"lucy\",\"studentAge\":15}]";

        val jsonArray = JSONArray(JSON_ARRAY_STR)

        //遍历方式1
        val size = jsonArray.length()
        for (i in 0 until size) {

            val jsonObject = jsonArray.getJSONObject(i)
            Log.v("puny","studentName:  " + jsonObject.getString("studentName") + ":" + "  studentAge:  "
                    + jsonObject.getInt("studentAge"))
        }

        //遍历方式2
//        for (obj in jsonArray) {
//
//            val jsonObject = obj as JSONObject
//            println("studentName:  " + jsonObject.getString("studentName") + ":" + "  studentAge:  "
//                    + jsonObject.getInt("studentAge"))
//        }
    }

    fun testfast1()
    {

        val JSON_OBJ_STR = "{\"studentName\":\"lily\",\"studentAge\":12}"
        // "[{\"studentName\":\"lily\",\"studentAge\":12},{\"studentName\":\"lucy\",\"studentAge\":15}]";
        //  "{\"teacherName\":\"crystall\",\"teacherAge\":27,\"course\":{\"courseName\":\"english\",\"code\":1270},\"students\":[{\"studentName\":\"lily\",\"studentAge\":12},{\"studentName\":\"lucy\",\"studentAge\":15}]}";

        //已知JSONObject,目标要转换为json字符串
        val jsonObject = JSONObject(JSON_OBJ_STR)
        // 第一种方式
        val jsonString = jsonObject.toString()

        // 第二种方式
        //String jsonString = jsonObject.toJSONString();
        Log.v("puny","jsonString="+jsonString)
    }

}

class Student {
    var studentName: String? = null
    var studentAge: Int = 0
}

// @SerializedName("name"); 当属性名称不对应的时候
class Person {
    var name: String? = null
    var age: Int = 0
    val books: List<Book>? = null
}

class Book {
    var mBookName:String? = null
    var mBookprice:Float = 0.0f
}

// 支持泛型类型
class Result<T> {
    val code:Int = -1
    val message:String = ""
    var data:T? = null
}
