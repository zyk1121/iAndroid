package com.example.thirdpartmodule

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import com.example.basemodule.base.BaseActivity
import okhttp3.Callback
import okhttp3.Response
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.http.GET
import java.io.IOException
import java.util.*
import com.google.gson.GsonBuilder
import com.google.gson.Gson
import retrofit2.converter.gson.GsonConverterFactory


// https://www.jianshu.com/p/b64a2de066c3
// https://www.jianshu.com/p/0fda3132cf98
// https://www.jianshu.com/p/308f3c54abdd

class ThirdpartRetrofitActivity : BaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_thirdpart_retrofit
    }

    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_thirdpart_retrofit)
        setTitle("Retrofit")
    }

    fun btnClick(view:View) {
        when (view.id) {
            R.id.retrofit_button1 -> {
                // retrofit 入门
                retrofitTest5()
            }
        }
    }

    fun retrofitTest5()
    {
        val gson = GsonBuilder()
                //配置你的Gson
                .setDateFormat("yyyy-MM-dd hh:mm:ss")
                .create()

        // http://192.168.0.3:8080/test.json
        val retro = Retrofit.Builder()
                .baseUrl("http://192.168.0.3:8080")
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()
        val request = retro.create(JsonService::class.java)
        val call = request.getData3()
        call.enqueue(object :retrofit2.Callback<ResultWrap<Address>> {
            override fun onFailure(call: Call<ResultWrap<Address>>?, t: Throwable?) {
                Log.v("puny", "data:onFailure")
            }

            override fun onResponse(call: Call<ResultWrap<Address>>?, response: retrofit2.Response<ResultWrap<Address>>?) {
                val data = response?.body()
                Log.v("puny", "data:" + data?.rs)
                Log.v("puny", "data:" + data?.resultMessage)
                Log.v("puny", "data:" + data?.resultMessage?.name)
            }

        })
    }

    fun retrofitTest4()
    {
        val gson = GsonBuilder()
                //配置你的Gson
                .setDateFormat("yyyy-MM-dd hh:mm:ss")
                .create()

        // http://192.168.0.3:8080/test.json
        val retro = Retrofit.Builder()
                .baseUrl("http://192.168.0.3:8080")
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()
        val request = retro.create(JsonService::class.java)
        val call = request.getData2()
        call.enqueue(object :retrofit2.Callback<ResultWrap<Map<String,Any>>> {
            override fun onFailure(call: Call<ResultWrap<Map<String,Any>>>?, t: Throwable?) {
                Log.v("puny", "data:onFailure")
            }

            override fun onResponse(call: Call<ResultWrap<Map<String,Any>>>?, response: retrofit2.Response<ResultWrap<Map<String,Any>>>?) {
                val data = response?.body()
                Log.v("puny", "data:" + data?.rs)
                Log.v("puny", "data:" + data?.resultMessage)
            }

        })
    }

    fun retrofitTest3()
    {
        val gson = GsonBuilder()
                //配置你的Gson
                .setDateFormat("yyyy-MM-dd hh:mm:ss")
                .create()

        // http://192.168.0.3:8080/test.json
        val retro = Retrofit.Builder()
                .baseUrl("http://192.168.0.3:8080")
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()
        val request = retro.create(JsonService::class.java)
        val call = request.getData()
        call.enqueue(object :retrofit2.Callback<ResultWrap<String>> {
            override fun onFailure(call: Call<ResultWrap<String>>?, t: Throwable?) {
                Log.v("puny", "data:onFailure")
            }

            override fun onResponse(call: Call<ResultWrap<String>>?, response: retrofit2.Response<ResultWrap<String>>?) {
                val data = response?.body()
                Log.v("puny", "data:" + data?.rs)
            }

        })
    }

    fun retrofitTest2()
    {
        // http://192.168.0.3:8080/test.json
        val retro = Retrofit.Builder()
                .baseUrl("http://192.168.0.3:8080")
                .build()
        val request = retro.create(JsonService::class.java)
        val call = request.postJsonData()
        call.enqueue(object :retrofit2.Callback<ResponseBody> {
            override fun onFailure(call: Call<ResponseBody>?, t: Throwable?) {
                Log.v("puny", "data:onFailure")
            }

            override fun onResponse(call: Call<ResponseBody>?, response: retrofit2.Response<ResponseBody>?) {
                val str = response?.body()?.string()
                Log.v("puny", "data:" + str)
            }

        })
    }

    fun retrofitTest1()
    {
        // http://192.168.0.3:8080/test.json
        val retro = Retrofit.Builder()
                .baseUrl("http://192.168.0.3:8080")
                .build()
        val request = retro.create(JsonService::class.java)
        val call = request.getJsonData()
        call.enqueue(object :retrofit2.Callback<ResponseBody> {
            override fun onFailure(call: Call<ResponseBody>?, t: Throwable?) {
                Log.v("puny", "data:onFailure")
            }

            override fun onResponse(call: Call<ResponseBody>?, response: retrofit2.Response<ResponseBody>?) {
                val str = response?.body()?.string()
                Log.v("puny", "data:" + str)
            }

        })
    }
}

interface JsonService {
    // 表单格式请求
// https://github.com/ikidou/Retrofit2Demo/blob/master/client/src/main/java/com/github/ikidou/Example03.java

    // header
//    https://github.com/ikidou/Retrofit2Demo/blob/master/client/src/main/java/com/github/ikidou/Example04.java

//    https://github.com/ikidou/Retrofit2Demo/blob/master/client/src/main/java/com/github/ikidou/Example05.java

    /*
    *         /**
         * 当GET、POST...HTTP等方法中没有设置Url时，则必须使用 {@link Url}提供
         * 对于Query和QueryMap，如果不是String（或Map的第二个泛型参数不是String）时
         * 会被默认会调用toString转换成String类型
         * Url支持的类型有 okhttp3.HttpUrl, String, java.net.URI, android.net.Uri
         * {@link retrofit2.http.QueryMap} 用法和{@link retrofit2.http.FieldMap} 用法一样，不再说明
         */
        @GET //当有URL注解时，这里的URL就省略了
        Call<ResponseBody> testUrlAndQuery(@Url String url, @Query("showAll") boolean showAll);

        */
    /*
    * /**
     * method 表示请求的方法，区分大小写
     * path表示路径
     * hasBody表示是否有请求体
     */
    @HTTP(method = "GET", path = "blog/{id}", hasBody = false)
    Call<ResponseBody> getBlog(@Path("id") int id);
*/
//    @GET("blog/{id}")
//    fun getBlog(@Path("id") id: Int): Call<ResponseBody>

    @GET("/test.json")
    fun getJsonData(): Call<ResponseBody>

    @GET("/test.json")
    fun postJsonData(): Call<ResponseBody>

    @GET("/test2.json")
    fun getData(): Call<ResultWrap<String>>

    @GET("/test.json")
    fun getData2(): Call<ResultWrap<Map<String,Any>>>

    @GET("/test.json")
    fun getData3(): Call<ResultWrap<Address>>
}

class ResultWrap<T> {
    var rs:Int = 0
    var errorMsg:String = ""
    var resultMessage:T? = null
}

class Address {
//    name=zyk, age=21.0, address=北京市朝阳区}
    var name:String = ""
    var age:Int = 0
    var address:String = ""
}

/*
* {
                                                                             	"rs": 1,
                                                                             	"errorMsg": "haha",
                                                                             	"resultMessage": {
                                                                             		"name": "zyk",
                                                                             		"age": 21,
                                                                             		"address": "北京市朝阳区"
                                                                             	},
                                                                             	"arrayData": ["1", "2", "3"],
                                                                             	"array2": [{
                                                                             		"name": "zyk1",
                                                                             		"age": 21,
                                                                             		"address": "北京市朝阳区1"
                                                                             	}, {
                                                                             		"name": "zyk2",
                                                                             		"age": 22,
                                                                             		"address": "北京市朝阳区2"
                                                                             	}, {
                                                                             		"name": "zyk3",
                                                                             		"age": 23,
                                                                             		"address": "北京市朝阳区3"
                                                                             	}]
                                                                             }
                                                                             */