package com.example.thirdpartmodule

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.ImageView
import com.example.basemodule.base.BaseActivity
import com.bumptech.glide.Glide


// https://blog.csdn.net/qq_31679853/article/details/78616289
//https://blog.csdn.net/Li_Qing_Xue/article/details/78919499
// https://blog.csdn.net/github_33304260/article/details/70213300
class ThirdpartGlideMainActivity : BaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_thirdpart_glide_main
    }

    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    private var iv1:ImageView? = null
    private var iv2:ImageView? = null
    private var iv3:ImageView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_thirdpart_glide_main)
        setTitle("Glide")
        iv1 = findViewById(R.id.third_imageView1)
        iv2 = findViewById(R.id.third_imageView2)
        iv3 = findViewById(R.id.third_imageView3)

        Handler().postDelayed(Runnable { kotlin.run {
            loadImage()
        } },3000)
    }

    /*
    * // 加载本地图片
File file = new File(getExternalCacheDir() + "/image.jpg");
Glide.with(this).load(file).into(imageView);

// 加载应用资源
int resource = R.drawable.image;
Glide.with(this).load(resource).into(imageView);

// 加载二进制流
byte[] image = getImageBytes();
Glide.with(this).load(image).into(imageView);

// 加载Uri对象
Uri imageUri = getImageUri();
Glide.with(this).load(imageUri).into(imageView);
*/
    fun loadImage2() {
        val url = "http://cn.bing.com/az/hprichbg/rb/Dongdaemun_ZH-CN10736487148_1920x1080.jpg"
        Glide.with(this).load(url).into(iv1)
    }

    fun loadImage3() {
        val url = "http://192.168.0.3:8080/icon/b1.jpg"
        Glide.with(this).load(url).into(iv1)
    }
    /*
    * Glide.with(this)
     .load(url)
     .placeholder(R.drawable.loading)
     .into(imageView);
     */
    fun loadImage() {
        val url = "http://192.168.0.3:8080/icon/b5.jpg"
        Glide.with(this).load(url).placeholder(R.drawable.icon11).into(iv1)
    }
    /*
    * 去掉缓存功能
    * Glide.with(this)
     .load(url)
     .placeholder(R.drawable.loading)
     .diskCacheStrategy(DiskCacheStrategy.NONE)
     .into(imageView);

    * */

    /*异常占位图：
    * 异常占位图的用法相信你已经可以猜到了，首先准备一张error.jpg图片，然后修改Glide加载部分的代码，如下所示：

Glide.with(this)
     .load(url)
     .placeholder(R.drawable.loading)
     .error(R.drawable.error)
     .diskCacheStrategy(DiskCacheStrategy.NONE)
     .into(imageView);*/

    /*
    * gif 自动判断
    *
    * http://p1.pstatp.com/large/166200019850062839d3
    *
    * 但是如果我想指定图片的格式该怎么办呢？就比如说，我希望加载的这张图必须是一张静态图片，我不需要Glide自动帮我判断它到底是静图还是GIF图。

想实现这个功能仍然非常简单，我们只需要再串接一个新的方法就可以了，如下所示：

Glide.with(this)
     .load(url)
     .asBitmap()
     .placeholder(R.drawable.loading)
     .error(R.drawable.error)
     .diskCacheStrategy(DiskCacheStrategy.NONE)
     .into(imageView);
     可以看到，这里在load()方法的后面加入了一个asBitmap()方法，这个方法的意思就是说这里只允许加载静态图片，不需要Glide去帮我们自动进行图片格式的判断了。


    * */

    /*gif 动图
    *
    * 由于调用了asBitmap()方法，现在GIF图就无法正常播放了，而是会在界面上显示第一帧的图片。

那么类似地，既然我们能强制指定加载静态图片，就也能强制指定加载动态图片。比如说我们想要实现必须加载动态图片的功能，就可以这样写：

Glide.with(this)
     .load(url)
     .asGif()
     .placeholder(R.drawable.loading)
     .error(R.drawable.error)
     .diskCacheStrategy(DiskCacheStrategy.NONE)
     .into(imageView);

     */



    /*
    * 指定图片大小
实际上，使用Glide在绝大多数情况下我们都是不需要指定图片大小的。

在学习本节内容之前，你可能还需要先了解一个概念，就是我们平时在加载图片的时候很容易会造成内存浪费。什么叫内存浪费呢？比如说一张图片的尺寸是1000*1000像素，但是我们界面上的ImageView可能只有200*200像素，这个时候如果你不对图片进行任何压缩就直接读取到内存中，这就属于内存浪费了，因为程序中根本就用不到这么高像素的图片。

关于图片压缩这方面，我之前也翻译过Android官方的一篇文章，感兴趣的朋友可以去阅读一下 Android高效加载大图、多图解决方案，有效避免程序OOM 。

而使用Glide，我们就完全不用担心图片内存浪费，甚至是内存溢出的问题。因为Glide从来都不会直接将图片的完整尺寸全部加载到内存中，而是用多少加载多少。Glide会自动判断ImageView的大小，然后只将这么大的图片像素加载到内存当中，帮助我们节省内存开支。

当然，Glide也并没有使用什么神奇的魔法，它内部的实现原理其实就是上面那篇文章当中介绍的技术，因此掌握了最基本的实现原理，你也可以自己实现一套这样的图片压缩机制。

也正是因为Glide是如此的智能，所以刚才在开始的时候我就说了，在绝大多数情况下我们都是不需要指定图片大小的，因为Glide会自动根据ImageView的大小来决定图片的大小。

不过，如果你真的有这样的需求，必须给图片指定一个固定的大小，Glide仍然是支持这个功能的。修改Glide加载部分的代码，如下所示：

Glide.with(this)
     .load(url)
     .placeholder(R.drawable.loading)
     .error(R.drawable.error)
     .diskCacheStrategy(DiskCacheStrategy.NONE)
     .override(100, 100)
     .into(imageView);
     */
}


/*
* 1、初始化
Glide支持Activity和Fragment的绑定

Glide.with(Context context);
Glide.with(Activity activity);
Glide.with(FragmentActivity activity);
Glide.with(Fragment fragment);
1
2
3
4
将Activity/Fragment作为with()参数的好处是:图片加载会和Activity/Fragment的生命周期保持一致

2、加载资源
Glide支持网络资源、assets资源、Resources资源、File资源、Uri资源、字节数组

Glide.with(this).load("http://pic9/258/a2.jpg").into(iv);
Glide.with(this).load("file:///xxx.jpg").into(iv);
Glide.with(this).load(R.mipmap.ic_launcher).into(iv);
Glide.with(this).load(file).into(iv);
Glide.with(this).load(uri).into(iv);
Glide.with(this).load(byte[]).into(iv);
1
2
3
4
5
6
3、加载gif图片
加载静态gif图片(静态就是gif相当于一张图片)
Glide.with(this).load(imageUrl).asBitmap().into(iv);
1
加载动态gif图片(gif是动的)
Glide.with(this).load(imageUrl).asGif().into(iv);
1
显示本地视频
Glide 还能显示视频！只要他们是存储在手机上的。假设你通过让用户选择一个视频后得到了一个文件路径：
String filePath = "/storage/emulated/0/Pictures/example_video.mp4";
Glide.with(context).load(Uri.fromFile(new File( filePath))).into(iv);
1
2
这里需要注意的是，这仅仅对本地视频起作用。如果没有存储在该设备上的视频(如一个网络 URL 的视频)，它是不工作的!

4、设置加载中和加载失败的图片
设置加载中图片
.placeholder(R.drawable.placeholder)
1
设置加载失败图片
.error(R.drawable.error)
1
设置缩略图支持
//先加载缩略图 然后在加载全图
Glide.with(this)
     .load(imageUrl)
     .thumbnail(0.1f)
     .into(iv);
1
2
3
4
5
5、设置加载动画
默认是淡入淡出动画
Glide.with(this)
.load("http://nm/photo/1f/1f7a.jpg")
.crossFade(int duration)//去减慢（或加快）动画
.into(iv);
1
2
3
4
使用 crossFade()
Glide.with(this)
.load("http://nm/photo/1f/1f7a.jpg")
.crossFade()//动画默认的持续时间是 300毫秒
.into(iv);
1
2
3
4
添加自定义动画
Glide.with(this)
.load("http://nm/photo/1f/1f7a.jpg")
.animate(R.anim.fade_in)
.into(iv);
1
2
3
4
去除动画
Glide.with(this)
.load("http://nm/photo/1f/1f7a.jpg")
.dontAnimate()
.into(iv);
1
2
3
4
6、 缩放图像
CenterCrop 即缩放图像至填充到 ImageView内,裁剪额外的部分。ImageView会完全填充，但图像可能不会显示不全。
Glide.with(this).load(url).centerCrop().into(iv);
1
fitCenter() 图片会按照imageview长宽中最小的边界作为依据,按比例缩放图像。该图像将会完全显示，但可能不会填满整个 ImageView。
Glide.with(this).load(url).fitCenter().into(iv);
1
7、设置监听回调
Glide.with(this)
    .load(imageUrl)
    .listener(RequestListener listener)
    .into(iv);
1
2
3
4
8、设置加载尺寸
指定尺寸(图片大小在xml中不能写死,是wrap_content才可以指定尺寸)
Glide.with(this)
.load("http://nm/photo/1f/1f7a.jpg")
.override(600,600)
.into(iv);
1
2
3
4
9、设置缓存策略
设置跳过内存缓存
Glide.with(this)
.load("http://nm/photo/1f/1f7a.jpg")
.skipMemoryCache(true)
.into(iv);
1
2
3
4
设置缓存策略
Glide.with(this)
.load("http://nm/photo/1f/1f7a.jpg")
.diskCacheStrategy(DiskCacheStrategy.ALL)
.into(iv);
DiskCacheStrategy.ALL //缓存源资源和转换后的资源
DiskCacheStrategy.NONE//不做任何磁盘缓存
DiskCacheStrategy.RESULT //缓存转换后的资源
DiskCacheStrategy.SOURCE缓存源资源
1
2
3
4
5
6
7
8
清理磁盘缓存
Glide.get(this).clearDiskCache();//在子线程中进行
1
清理内存缓存
Glide.get(this).clearMemory();//可以在主线程
1
设置磁盘缓存目录和图片效果(默认Bitmap格式是RGB_565)
1,在AndroidManifest中application节点下:
<!--glide缓存目录设置-->
 <meta-data
     android:name="包名.widget.GlideModuleConfig"
     android:value="GlideModule" />
1
2
3
4
2 , 创建类GlideModuleConfig

public class GlideModuleConfig implements GlideModule {
    @Override
    public void applyOptions(Context context, GlideBuilder builder) {
//内部存储/Android/data/包名/cache/glide-images
builder.setDiskCache(new ExternalCacheDiskCacheFactory(context, "glide-images", 2 * 1024 * 1024));
//将默认的RGB_565效果转换到ARGB_8888
 builder.setDecodeFormat(DecodeFormat.PREFER_ARGB_8888);
    }

    @Override
    public void registerComponents(Context context, Glide glide) {
        //不做处理
    }
}
1
2
3
4
5
6
7
8
9
10
11
12
13
14
10、BitmapTransformation
Glide在Github上还有一个库，可以处理图片效果，比如裁剪、圆角、高斯模糊等等

引入依赖库
compile 'jp.wasabeef:glide-transformations:2.0.1'
1
实现高斯模糊
//radius取值1-25,值越大图片越模糊
Glide.with(context).load(url).bitmapTransform(new BlurTransformation(context, radius)).into(iv);
1
2
原图基础上变换设置圆形图
Glide.with(context).load(url).bitmapTransform(new CropCircleTransformation(this)).into(iv);
1
原图基础上变换成圆图 +毛玻璃（高斯模糊）
Glide.with(this).load(url).bitmapTransform(new BlurTransformation(this, 25), new CropCircleTransformation(this)).into(iv);
1
原图处理成圆角
//如果是四周已经是圆角则RoundedCornersTransformation.CornerType.ALL
Glide.with(this)
                .load(url)
                .bitmapTransform(new RoundedCornersTransformation(this, 30, 0, RoundedCornersTransformation.CornerType.BOTTOM))
                .into(iv);
*/