package com.example.thirdpartmodule

import android.app.Activity
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.Nullable
import android.util.Log
import android.view.View
import android.widget.Button
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.OnClick
import com.example.basemodule.base.BaseActivity
import kotlinx.android.synthetic.main.activity_thirdpart_annotation.view.*
import android.widget.EditText
import android.widget.Toast
import butterknife.Optional


// https://blog.csdn.net/donkor_/article/details/77879630
// https://blog.csdn.net/donkor_/article/details/77879630
// https://blog.csdn.net/twopai/article/details/56017010
//https://blog.csdn.net/doris_d/article/details/52607564
// https://blog.csdn.net/huaxun66/article/details/52691459
// https://blog.csdn.net/qq402164452/article/details/60779660
// https://www.jianshu.com/p/79f1d94e45cf

// https://www.jianshu.com/p/b55a50b4b921
class ThirdpartAnnotationActivity : BaseActivity() {

    /*
    *   Java的注解(Annotation)相当于一种标记，在程序中加入注解就等于为程序打上某种标记，标记可以加在包，类，属性，方法，本地变量上。然后你可以写一个注解处理器去解析处理这些注解(人称编译时注解)，也可以在程序运行时利用反射得到注解做出相应的处理(人称运行时注解)。
       开发android程序时，没完没了的findViewById, setOnClickListener等等方法，已经让大多数开发者头疼不已。好在市面上有所谓的注解框架可以帮助开发者简化一些过程。比较流行的有butterknife, annotations, xutils, afinal, roboguice等等。今天我们就来对比一下这些注解框架。
       */
    // butterknife
    override fun getLayoutId(): Int {
        return R.layout.activity_thirdpart_annotation
    }

    override fun afterCreate(savedInstanceState: Bundle?) {
    }


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_thirdpart_annotation)
//        setTitle("Android注解框架")

        ButterKnife.bind(this)
//        btn2?.setBackgroundColor(Color.RED)
    }

    // 解决组件化开发butterknife 在 library中使用的坑:https://www.jianshu.com/p/c6e3f67e391e
    /*
    * Error:(10, 2) 错误: @BindView fields must not be private or static. (com.example.thirdpartmodule.ThirdpartAnnotationActivity.btn)
    private android.widget.Button btn;
                                  ^

                                  */
//    @Nullable
//    @BindView(R2.id.btn_test)
//    public var btn2: Button? = null
//
//    @BindView(R2.id.btn_test) var btn2: Button? = null

    @Optional
    @OnClick(R2.id.btn_test)
    public fun showToast() {
        Log.v("puny","hhhhhhhhhhhh")
        Toast.makeText(this,"dddddd",Toast.LENGTH_SHORT).show()
    }
}


/*
* (一)、View的绑定
1. 控件id的注解：@BindView()

1 @BindView(R.id.toolbar)
2 public Toolbar toolbar;
然后再Activity的onCreate()中调用：

1 ButterKnife.bind( this ) ;
2. 多个控件id 注解： @BindViews()

1     @BindViews({ R.id.button1  , R.id.button2 ,  R.id.button3 })
2     public List<Button> buttonList ;
然后再Activity的onCreate()中调用：

1 ButterKnife.bind( this ) ;
3. 绑定其他View中的控件
Butter Knife提供了bind的几个重载，只要传入跟布局，便可以在任何对象中使用注解绑定。调用ButterKnife.bind(view. this);方法。但是一般调用 Unbinder unbinder=ButterKnife.bind(view, this)方法之后需要在调用 unbinder.unbind()解绑。
所以一般在activity中调用之后再绑定其他的view中的控件时我都会使用（四）中的方法。
*/




/*
*     @BindView(R.id.text)//注解单个控件,使用的是@BindView
            TextView text;
    @BindViews({R.id.btn, R.id.btn2, R.id.btn3, R.id.go_secondPage})//批量注解控件,使用的是@BindViews
            List<Button> buttons;
    @BindString(R.string.china_value)//注解字符串资源文件
            String china;
    @BindString(R.string.english_value)//注解字符串资源文件
    String eng;
    @BindString(R.string.number_value)//注解字符串资源文件
    String num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //初始化BUtterKnife框架，可写在项目基类里面。
        ButterKnife.bind(this);

    }

    //注解点击事件，注意不要放在Oncreate()等生命周期中，否则编译报错
    @OnClick({R.id.btn, R.id.btn2, R.id.btn3, R.id.go_secondPage})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn:
                text.setText(china);
                break;
            case R.id.btn2:
                text.setText(eng);
                break;
            case R.id.btn3:
                text.setText(num);
                break;
            case R.id.go_secondPage:
                startActivity(new Intent(MainActivity.this, SecondActivity.class));
                break;
        }
    }

}
*/


/*
*
* // Top-level build file where you can add configuration options common to all
sub-projects/modules.

buildscript {
ext.kotlin_version = '1.2.30'
ext.google_ver = '27.1.0'
ext.google_play_ver = '11.8.0'
ext.retrofit_ver = '2.3.0'
ext.arch_components_ver = '1.1.1'

repositories {
    jcenter()
    google()
    maven { url "https://kotlin.bintray.com/kotlinx" }

    mavenLocal()
}
dependencies {
    classpath 'com.android.tools.build:gradle:3.2.0-alpha07'

    // NOTE: Do not place your application dependencies here; they belong
    // in the individual module build.gradle files
    classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:$kotlin_version"
    classpath "org.jetbrains.kotlin:kotlin-android-extensions:$kotlin_version"
    classpath 'com.google.gms:google-services:3.1.2'
}
}
allprojects {
repositories {
    jcenter()
    mavenCentral()
    maven { url "https://jitpack.io" }
    maven {
        url "https://maven.google.com"
    }
    maven { url "https://kotlin.bintray.com/kotlinx" }
    google()
    flatDir { dirs 'libs' }
}
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
app.gradle

apply plugin: 'com.android.application'
apply plugin: 'kotlin-android'
apply plugin: 'kotlin-android-extensions'
apply plugin: 'kotlin-kapt'

androidExtensions {
    experimental = true
}




android {
compileSdkVersion 27
defaultConfig {
    applicationId "xxx"
    minSdkVersion 19
    targetSdkVersion 27
    versionCode 1
    versionName "1.0"
    multiDexEnabled true
    dataBinding {
        enabled = true
    }
}
buildTypes {
    release {
        minifyEnabled false
        proguardFiles getDefaultProguardFile('proguard-android.txt'),
'proguard-rules.pro'
    }
}
}

kapt {
    generateStubs = true
}

dependencies {
implementation fileTree(dir: 'libs', include: ['*.jar'])
implementation "com.android.support:support-v4:$google_ver"
implementation 'com.android.support:support-v4:27.1.0'
compile fileTree(include: ['*.jar'], dir: 'libs')
implementation "org.jetbrains.kotlin:kotlin-stdlib:$kotlin_version"
implementation "org.jetbrains.kotlin:kotlin-reflect:$kotlin_version".0.2'
implementation "com.android.support:design:$google_ver"
implementation "com.android.support:appcompat-v7:$google_ver"
implementation 'devs.mulham.horizontalcalendar:horizontalcalendar:1.1.7'
implementation "org.jetbrains.kotlin:kotlin-stdlib-jre7:$kotlin_version"
implementation 'com.bluelinelabs:conductor:2.1.4'
implementation 'com.bluelinelabs:conductor-support:2.1.4'
implementation 'com.jakewharton.threetenabp:threetenabp:1.0.5'
implementation 'com.annimon:stream:1.1.7'
implementation "com.squareup.retrofit2:retrofit:$retrofit_ver"
implementation "com.squareup.retrofit2:adapter-rxjava2:$retrofit_ver"
implementation 'com.squareup.retrofit2:converter-moshi:2.0.0'
implementation "com.squareup.retrofit2:retrofit:$retrofit_ver"
implementation "com.squareup.retrofit2:converter-gson:$retrofit_ver"
implementation 'com.squareup.moshi:moshi-kotlin:1.5.0'
implementation 'io.reactivex.rxjava2:rxjava:2.1.7'
implementation 'io.reactivex.rxjava2:rxandroid:2.0.1'
implementation 'jp.wasabeef:glide-transformations:3.0.1'
implementation 'com.fasterxml.jackson.module:jackson-module-kotlin:2.9.0'
implementation "com.android.support:support-v4:$google_ver"
implementation "com.google.android.gms:play-services-maps:$google_play_ver"
implementation "com.google.android.gms:play-services-gcm:$google_play_ver"
implementation 'com.makeramen:roundedimageview:2.3.0'
implementation 'com.google.code.gson:gson:2.8.0'
implementation "org.jetbrains.kotlin:kotlin-reflect:$kotlin_version"
implementation 'com.squareup.okhttp3:logging-interceptor:3.4.1'
implementation 'com.cleveroad:slidingtutorial:0.9.5'
implementation 'io.reactivex:rxjava:1.3.2'
//camera
implementation 'io.fotoapparat.fotoapparat:library:1.4.1'
implementation 'id.zelory:compressor:2.1.0'
//ui
implementation 'com.davemorrissey.labs:subsampling-scale-image-view:3.9.0'
implementation 'com.akexorcist:RoundCornerProgressBar:2.0.3'
implementation 'com.ebanx:swipe-button:0.8.3'
implementation 'com.github.ViksaaSkool:AutoFitEditText:53238e2d29'
implementation 'ru.egslava:MaskedEditText:1.0.5'
implementation 'org.jetbrains.anko:anko-common:0.8.3'
implementation 'com.rengwuxian.materialedittext:library:2.1.4'
implementation 'com.afollestad.material-dialogs:core:0.9.6.0'
//    rxBinding
implementation 'com.jakewharton.rxbinding:rxbinding:1.0.0'

implementation 'com.android.support.constraint:constraint-layout:1.0.2'

// ViewModel and LiveData
implementation "android.arch.lifecycle:extensions:$ext.arch_components_ver"
implementation "android.arch.lifecycle:common-java8:$ext.arch_components_ver"
implementation "android.arch.lifecycle:reactivestreams:$ext.arch_components_ver"
}

*/