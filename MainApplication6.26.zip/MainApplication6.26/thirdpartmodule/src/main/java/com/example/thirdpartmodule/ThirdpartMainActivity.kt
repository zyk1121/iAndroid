package com.example.thirdpartmodule

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import com.example.basemodule.base.BaseActivity

class ThirdpartMainActivity : BaseActivity() {

    // 闭包表达式使用
    fun test6()
    {
//        val cal:(Int) -> Unit = {
//            Log.d("puny", it.toString())
//        }
        // 闭包2
//        val cal2 = { x: Int, y: Int ->
////            println("${x + y}")
//            Log.d("puny", "${x + y}")
//        }
//
//        cal2(10,20)

        // 闭包3
//        val cal3:(Int,Int)->Int = { i: Int, i1: Int ->
//            10 + 20
//            20+30
//            30+30
//        }
//        val dd = cal3(10,10)
//        Log.d("puny", "${dd}")

        // 闭包4
//        val cal3:(Int,Int)->Int = { i: Int, i1: Int ->
//            i + i1
//        }
//        val dd = cal3(10,10)
//        Log.d("puny", "${dd}")

        // 闭包5
//        val cal5:(Int)->String = { i: Int ->
//            "${i}"
//            "${i}"
//            "${i + 40}"
//// 最后一行未lambda的返回值
//        }
//        val dd = cal5(10)
//        Log.d("puny", "${dd}")

        // 闭包6
//        val cal6 = { i: Int ->
//             i * 2
//                i+ 2
//            "${i + 40}" + "abcdef"
//// 最后一行未lambda的返回值
//        }
//        val dd = cal6(10)
//        Log.d("puny", "${dd}")


        // 返回一个信号
//        val myTest = { it:Int ->
//            Observable.just(it)
//        }
//
//        myTest(10).subscribe {
//            Log.d("puny", "${it}")
//        }

        val myTest = {it:Int ->

        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_thirdpart_main)
        setTitle("Android第三方")
        listView = findViewById(R.id.thirdpart_list_view)
        listView?.adapter = MyListAdapter(this)
//        listView?.setOnItemClickListener { parent, view, position, id -> Toast.makeText(this,"cecshi",Toast.LENGTH_SHORT).show() }
//        listView?.setOnItemClickListener { parent, view, position, id ->  {
//            Toast.makeText(this,"cecshi22",Toast.LENGTH_SHORT).show()
//        }()}
//        listView?.setOnItemClickListener(this)

        listView?.setOnItemClickListener { parent, view, position, id ->
            {
                //                Toast.makeText(this, listDatas.get(position), Toast.LENGTH_SHORT).show()
                onItemClick(position)
            }()
        }
    }
    override fun getLayoutId(): Int {
        return R.layout.activity_thirdpart_main
    }
    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    private var listView: ListView? = null

    public var listDatas:Array<String> =
            arrayOf(
                    "1、OKHttp",
                    "2、Retrofit",
                    "3、JSON解析",
                    "4、RxJava2",
                    "5、Glide图片加载",
                    "6、Fresco图片加载",
                    "7、Android注解框架")
    // 点击了某个cell
    fun onItemClick(position: Int) {
        val intent = Intent()
        intent.setClass(this, ThirdpartOKHttpActivity::class.java)
        when (position) {
            0 -> intent.setClass(this,ThirdpartOKHttpActivity::class.java)
            1 -> intent.setClass(this,ThirdpartRetrofitActivity::class.java)
            2 -> intent.setClass(this,ThirdpartJSONActivity::class.java)
            3 -> intent.setClass(this,ThirdpartRxJavaActivity::class.java)
            4 -> intent.setClass(this,ThirdpartGlideMainActivity::class.java)
            5 -> intent.setClass(this,ThirdpartFrescoActivity::class.java)
            6 -> intent.setClass(this,ThirdpartAnnotationActivity::class.java)

        }

        startActivity(intent)

    }

    inner class MyListAdapter(tempContext: Context): BaseAdapter() {

        var context: Context = tempContext

        override fun getItem(position: Int): String {
            return listDatas.get(position)
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getCount(): Int {
            return listDatas.size
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            var viewHolder: ViewHolder
            var view: TextView

            if (convertView == null) {
                view = TextView(context)
                view.textSize = 30F
                viewHolder = ViewHolder(view)
                view.setTag(viewHolder)
            } else {
                view = convertView as TextView
                viewHolder = view.getTag() as ViewHolder
            }

            viewHolder.item_cell.text = listDatas.get(position)

            return view
        }
    }

    class ViewHolder(var v: View) {
        var item_cell: TextView = v as TextView
    }
}
