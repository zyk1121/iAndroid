package com.example.thirdpartmodule

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import com.example.basemodule.base.BaseActivity
import okhttp3.*
import java.io.IOException

/*
* 在使用OKHttp之前，首先要先了解如下几个比较核心的类：

OkHttpClient：客户端对象
Request：访问请求，Post请求中需要包含RequestBody
RequestBody：请求数据，在Post请求中用到
Response：即网络请求的响应结果
MediaType：数据类型，用来表明数据是json，image，pdf等一系列格式
client.newCall(request).execute()：同步的请求方法
client.newCall(request).enqueue(Callback callBack)：异步的请求方法，但Callback是执行在子线程中的，因此不能在此进行UI更新操作

*/

// https://www.jianshu.com/p/ca8a982a116b
// https://www.jianshu.com/p/7b29b89cd7b5
//https://blog.csdn.net/carson_ho/article/details/73732076
class ThirdpartOKHttpActivity : BaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_thirdpart_okhttp
    }

    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_thirdpart_okhttp)
        setTitle("OKHttp")

        setupUI()
    }

    lateinit var button: Button
    lateinit var button2: Button

    fun setupUI() {
        button = findViewById<Button>(R.id.third_button)
        button.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button2 = findViewById<Button>(R.id.third_button2)
        button2.setOnClickListener { it ->
            buttonClick(it as Button)
        }
    }

    fun buttonClick(button: Button) {
//        Toast.makeText(this,"button click:" + button.id.toString(),Toast.LENGTH_SHORT).show()
        when (button.id) {
            R.id.third_button -> {
                testGet()
            }
            R.id.third_button2 -> {
                testPost()
            }
        }
    }

    fun testPost() {
        Log.v("puny", "post start")
        val JSON:MediaType = MediaType.parse("application/json;charset=utf-8")!!
        val client = OkHttpClient()
        // http://www.jianshu.com/u/9df45b87cfdf
        // http://op.juhe.cn/onebox/news/query
        val requestBody = RequestBody.create(JSON,"")
        // http://192.168.0.3:8080/test.json http://www.baidu.com
        val request = Request.Builder().post(requestBody).url("http://192.168.0.3:8080/test.json").build()
//        val request =  Request.Builder().get().url("http://www.baidu.com").build()
        //构造Request对象
        //采用建造者模式，链式调用指明进行Get请求,传入Get的请求地址
        val call = client.newCall(request)
        //异步调用并设置回调函数

        call.enqueue(object : Callback {
            override fun onFailure(call: Call?, e: IOException?) {
                Log.v("puny", "data:onFailure")
            }

            override fun onResponse(call: Call?, response: Response?) {
                val str = response?.body()?.string()
                Log.v("puny", "data:" + str)

                /*
                * 在网络请求过程中出现了这个问题：

                okhttp3.internal.http.RealResponseBody@2be8f5f6 请求下来的数据一直无法进行解析，如图

            困惑了好长时间，终于想出了了解决方案：

            将 String  res = response.body().toString();换成String res = response.body().string();即可.


        */
            }
        })
    }
    fun testPost3()
    {
        val MEDIA_TYPE_MARKDOWN = MediaType.parse("text/x-markdown; charset=utf-8")

        val client = OkHttpClient()

        val postBody = "" + "Releases\n" + "--------\n" + " * _1.0_ May 6, 2013\n" + " * _1.1_ June 15, 2013\n" + " * _1.2_ August 11, 2013\n"

        val request = Request.Builder()
                .url("https://api.github.com/markdown/raw")
                .post(RequestBody.create(MEDIA_TYPE_MARKDOWN, postBody))
                .build()
        val response =  client.newCall(request).execute()

        if (!response.isSuccessful()) throw IOException("Unexpected code " + response)

        Log.v("puny", "data:" + response.body()?.string())
    }

    // http://192.168.0.3:8080/test.json

    fun testGet() {
        val client = OkHttpClient()
        // http://www.jianshu.com/u/9df45b87cfdf
        // http://op.juhe.cn/onebox/news/query
        val request = Request.Builder().get().url("http://192.168.0.3:8080/test.json").build()
//        val request =  Request.Builder().get().url("http://www.baidu.com").build()
        //构造Request对象
        //采用建造者模式，链式调用指明进行Get请求,传入Get的请求地址
        val call = client.newCall(request)
        //异步调用并设置回调函数

        call.enqueue(object : Callback {
            override fun onFailure(call: Call?, e: IOException?) {
                Log.v("puny", "data:onFailure")
            }

            override fun onResponse(call: Call?, response: Response?) {
                val str = response?.body()?.string()
                Log.v("puny", "data:" + str)

                /*
                * 在网络请求过程中出现了这个问题：

                okhttp3.internal.http.RealResponseBody@2be8f5f6 请求下来的数据一直无法进行解析，如图

            困惑了好长时间，终于想出了了解决方案：

            将 String  res = response.body().toString();换成String res = response.body().string();即可.


        */
            }
        })
    }

    fun testGet33(){
        // 同步请求
        Thread(Runnable { kotlin.run {
            val JSON:MediaType = MediaType.parse("application/json;charset=utf-8")!!
            val client = OkHttpClient()
            val request = Request.Builder().get().url("http://op.juhe.cn/onebox/news/query").build()
            val response = client.newCall(request).execute()
            val str = response.body()?.string()
            // {"resultcode":"101","reason":"错误的请求KEY","result":null,"error_code":10001}
            Log.v("puny", "data:" + str)

            /*
            * 在网络请求过程中出现了这个问题：

            okhttp3.internal.http.RealResponseBody@2be8f5f6 请求下来的数据一直无法进行解析，如图

        困惑了好长时间，终于想出了了解决方案：

        将 String  res = response.body().toString();换成String res = response.body().string();即可.


    */
        } }).start()
    }

    fun testGet3()
    {
        /*
        public static final MediaType JSON = MediaType.parse("application/json;charset=utf-8");

        public static String httpGet(String url) throws IOException {
            OkHttpClient httpClient = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(url)
                    .build();
            Response response = httpClient.newCall(request).execute();
            return response.body().string(); // 返回的是string 类型，json的mapper可以直接处理
        }

        public static String httpPost(String url, String json) throws IOException {
        OkHttpClient httpClient = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .post(requestBody)
                .build();
        Response response = httpClient.newCall(request).execute();
        return response.body().string();
        */
    }

    fun testGet2() {
//        OkHttpClient client = new OkHttpClient();
//        //构造Request对象
//        //采用建造者模式，链式调用指明进行Get请求,传入Get的请求地址
//        Request request = new Request.Builder().get().url("http://www.jianshu.com/u/9df45b87cfdf").build();
//        Call call = client.newCall(request);
//        //异步调用并设置回调函数
//        call.enqueue(new Callback() {
//            @Override
//            public void onFailure(Call call, IOException e) {
//                ToastUtil.showToast(GetActivity.this, "Get 失败");
//            }
//
//            @Override
//            public void onResponse(Call call, final Response response) throws IOException {
//                final String responseStr = response.body().string();
//                runOnUiThread(new Runnable() {
//
//                });
    }

    fun testPost2()
    {
//        public static final MediaType MEDIA_TYPE_MARKDOWN
//        = MediaType.parse("text/x-markdown; charset=utf-8");
//
//        private final OkHttpClient client = new OkHttpClient();
//
//        public void run() throws Exception {
//            String postBody = ""
//            + "Releases\n"
//            + "--------\n"
//            + "\n"
//            + " * _1.0_ May 6, 2013\n"
//            + " * _1.1_ June 15, 2013\n"
//            + " * _1.2_ August 11, 2013\n";
//
//            Request request = new Request.Builder()
//                    .url("https://api.github.com/markdown/raw")
//                    .post(RequestBody.create(MEDIA_TYPE_MARKDOWN, postBody))
//                    .build();
//
//            Response response = client.newCall(request).execute();
//            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);
//
//            System.out.println(response.body().string());
//        }


    }

    fun testpost44()
    {
        /*
        * //设置媒体类型。application/json表示传递的是一个json格式的对象
        MediaType mediaType = MediaType.parse("application/json");
        //使用JSONObject封装参数
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("参数名","参数值");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        //创建RequestBody对象，将参数按照指定的MediaType封装
        RequestBody requestBody = RequestBody.create(mediaType,jsonObject.toString());
        Request request = new Request
                .Builder()
                .post(requestBody)//Post请求的参数传递
                .url(Config.POST_URL)
                .build();
        try {
            Response response = okHttpClient.newCall(request).execute();
            String result = response.body().string();
            Log.d("androixx.cn",result);
            response.body().close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        */
    }

}

/*
* public class OkHttpUtil {

    //保证OkHttpClient是唯一的
    private static OkHttpClient okHttpClient;

    static Handler mHandler = new Handler();

    static {
        if (okHttpClient == null) {
            okHttpClient = new OkHttpClient();
        }
    }

    /**
     * Get请求
     * @param url
     * @param callback 回调函数
     */
    public static void httpGet(String url, final IOkCallBack callback) {

        if (callback == null) throw new NullPointerException("callback is null");

        Request request = new Request.Builder().url(url).build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, final IOException e) {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onException(e);
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(result);
                    }
                });
                response.body().close();
            }
        });
    }

    /**
     * Post请求
     * @param url
     * @param params 参数
     * @param callback 回调函数
     */
    public static void httpPost(String url,Map<String,String> params,final IOkCallBack callback) {
        if (callback == null) throw new NullPointerException("callback is null");
        if (params == null) throw new NullPointerException("params is null");

        FormBody.Builder formBodyBuilder = new FormBody.Builder();
        Set<String> keySet = params.keySet();
        for(String key:keySet) {
            String value = params.get(key);
            formBodyBuilder.add(key,value);
        }
        FormBody formBody = formBodyBuilder.build();

        Request request = new Request
                .Builder()
                .post(formBody)
                .url(url)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, final IOException e) {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onException(e);
                    }
                });

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(result);
                    }
                });
                response.body().close();
            }
        });
    }
}
*/
