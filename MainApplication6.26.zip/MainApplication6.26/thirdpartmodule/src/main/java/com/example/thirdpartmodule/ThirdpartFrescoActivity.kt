package com.example.thirdpartmodule

import android.net.Uri
import android.os.Bundle
import android.util.Log
import com.example.basemodule.base.BaseActivity
import com.example.basemodule.utils.YKUtils
import com.facebook.drawee.backends.pipeline.Fresco
import com.facebook.drawee.view.SimpleDraweeView

// https://blog.csdn.net/github_33304260/article/details/70213300
// https://blog.csdn.net/ljy_programmer/article/details/78273267
class ThirdpartFrescoActivity : BaseActivity() {

    override fun getLayoutId(): Int {
        initFresco()
        return R.layout.activity_thirdpart_fresco
    }

    override fun afterCreate(savedInstanceState: Bundle?) {
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_thirdpart_fresco)
        setTitle("Fresco")

        imageView = findViewById(R.id.sd_im1)
//        imageView?.setBackgroundColor(Color.RED)
        test()
    }

    var imageView:SimpleDraweeView? = null

    fun initFresco()
    {
//        setConfig()
        // 运行报错了！怎么回事呢？这里啊，是因为我们没有在应用调用 setContentView() 之前进行初始化Fresco造成的；解决办法：
        //https://blog.csdn.net/wyb112233/article/details/49637685
        Fresco.initialize(this)
    }

    fun test()
    {

//        https://blog.csdn.net/wyb112233/article/details/49637685
        // 1
//        val url = "http://192.168.0.3:8080/icon/b1.jpg"
//        imageView?.setImageURI(url)

        // 2
//        val url = "http://192.168.0.3:8080/icon/b1.jpg"
//        imageView?.setImageResource(R.drawable.icon5)

//        val imageURi = Uri.parse("http://192.168.0.3:8080/icon/b1.jpg")
//        imageView?.setImageURI(imageURi)
//        imageView?.setImageURI(imageURi,self)

        YKUtils.after(2000,{
            val imageURi = Uri.parse("http://192.168.0.3:8080/icon/b1.jpg")
            imageView?.setImageURI(imageURi)
        })

        // 测试闭包

//        YKUtils.testBlock(3000, completion = {x:Int,y:Int ->
//                val s= x+y
//            Log.d("puny", "x+y= ${s}")
//                x*y
//            // 最后一行代码是返回值
//            x*y
//            })

        YKUtils.testBlock(3000, {x:Int,y:Int ->
            val s= x+y
            Log.d("puny", "x+y= ${s}")
            x*y
            // 最后一行代码是返回值
            x*y
        })

        YKUtils.testBlock2(5000, {x:Int,y:Int ->
            val s= x-y
            Log.d("puny", "x-y= ${s}")
            x*y
            // 最后一行代码是返回值
            x*y
        })
        YKUtils.testBlock2(3000, null)
    }


    // https://blog.csdn.net/ljy_programmer/article/details/78273267
    fun setConfig()
    {


        /*
        *
        * 1.8 初始化
上面的各种配置都是通过ImagePipelineConfig进行的，接着需要进行初始化，在Application中初始化即可

ImagePipelineConfig.Builder imagePipelineConfigBuilder = ImagePipelineConfig.newBuilder(context);

//...进行各种设置

ImagePipelineConfig config = imagePipelineConfigBuilder.build();
Fresco.initialize(context, config);
1
2
3
4
5
6
如果想直接使用默认的配置，可以

Fresco.initialize(context);



        * */

//        // 设置磁盘缓存
//        val imagePipelineConfigBuilder = ImagePipelineConfig.Builder(this)
//        imagePipelineConfigBuilder.setMainDiskCacheConfig(DiskCacheConfig.newBuilder(this)
//                .setBaseDirectoryPath(this.getExternalCacheDir())//设置磁盘缓存的路径
////                .setBaseDirectoryName(.APP_IMAGE)//设置磁盘缓存文件夹的名称
//                .setMaxCacheSize(1024*10*1024)//设置磁盘缓存的大小
//                .build())

        /*
        *
        *  设置内存缓存
设置已解码的内存缓存（Bitmap缓存）

ImagePipelineConfig.Builder imagePipelineConfigBuilder = ImagePipelineConfig.newBuilder(context);
imagePipelineConfigBuilder.setBitmapMemoryCacheParamsSupplier(new Supplier<MemoryCacheParams>() {
       public MemoryCacheParams get() {
           int MAX_HEAP_SIZE = (int) Runtime.getRuntime().maxMemory();
           int MAX_MEMORY_CACHE_SIZE = MAX_HEAP_SIZE / 5;//取手机内存最大值的五分之一作为可用的最大内存数

           MemoryCacheParams bitmapCacheParams = new MemoryCacheParams( //
                   // 可用最大内存数，以字节为单位
                   MAX_MEMORY_CACHE_SIZE,
                   // 内存中允许的最多图片数量
                   Integer.MAX_VALUE,
                   // 内存中准备清理但是尚未删除的总图片所可用的最大内存数，以字节为单位
                   MAX_MEMORY_CACHE_SIZE,
                   // 内存中准备清除的图片最大数量
                   Integer.MAX_VALUE,
                   // 内存中单图片的最大大小
                   Integer.MAX_VALUE);
           return bitmapCacheParams;
       }
   });

   */

        /*
        * 设置未解码的内存缓存

ImagePipelineConfig.Builder imagePipelineConfigBuilder = ImagePipelineConfig.newBuilder(context);
imagePipelineConfigBuilder.setEncodedMemoryCacheParamsSupplier(new Supplier<MemoryCacheParams>() {
       public MemoryCacheParams get() {

           MemoryCacheParams bitmapCacheParams;
           //设置大小，可参考上面已解码的内存缓存
           return bitmapCacheParams;
       }
   });
   */

        /*
        * 设置内存紧张时的应对措施
MemoryTrimmableRegistry memoryTrimmableRegistry = NoOpMemoryTrimmableRegistry.getInstance();
memoryTrimmableRegistry.registerMemoryTrimmable(new MemoryTrimmable() {
     @Override
     public void trim(MemoryTrimType trimType) {
         final double suggestedTrimRatio = trimType.getSuggestedTrimRatio();

         if (MemoryTrimType.OnCloseToDalvikHeapLimit.getSuggestedTrimRatio() == suggestedTrimRatio
         || MemoryTrimType.OnSystemLowMemoryWhileAppInBackground.getSuggestedTrimRatio() == suggestedTrimRatio
         || MemoryTrimType.OnSystemLowMemoryWhileAppInForeground.getSuggestedTrimRatio() == suggestedTrimRatio) {
                 //清空内存缓存
                 ImagePipelineFactory.getInstance().getImagePipeline().clearMemoryCaches();
         }
     }
 });

ImagePipelineConfig.Builder imagePipelineConfigBuilder = ImagePipelineConfig.newBuilder(context);
imagePipelineConfigBuilder.setMemoryTrimmableRegistry(memoryTrimmableRegistry);
*/

        /*
        * 设置渐进式显示的效果
ProgressiveJpegConfig progressiveJpegConfig = new ProgressiveJpegConfig() {
      @Override
      public int getNextScanNumberToDecode(int scanNumber) {
          //返回下一个需要解码的扫描次数
          return scanNumber + 2;
      }

      public QualityInfo getQualityInfo(int scanNumber) {
          boolean isGoodEnough = (scanNumber >= 5);
          //确定多少个扫描次数之后的图片才能开始显示。
          return ImmutableQualityInfo.of(scanNumber, isGoodEnough, false);
      }
};
//具体含义可参考 http://wiki.jikexueyuan.com/project/fresco/progressive-jpegs.html

ImagePipelineConfig.Builder imagePipelineConfigBuilder = ImagePipelineConfig.newBuilder(context);
imagePipelineConfigBuilder.setProgressiveJpegConfig(progressiveJpegConfig);
//或者使用默认的效果
//imagePipelineConfigBuilder.setProgressiveJpegConfig(new SimpleProgressiveJpegConfig());
*/
    }
}




/*
* bitmap操作
Glide

Bitmap myBitmap = Glide.with(上下文)
    .load(url)
    .asBitmap() //必须
    .get()
1
2
3
4
Fresco
Fresco要获取bitmap更加复杂， 而且使用起来也并不是那么顺畅。首先，Fresco为了更好地管理bitmap 对象（bitmap对象申请和释放会引起频繁的GC操作，从而引起界面卡顿）， 引入了可关闭的引用（CloseableReference）, 持有者在离开作用域的时候需要关闭该引用，而我们要获取的bitmap 对象就是可关闭的引用。也就是说，我们不能像上面Glide那样把bitmap 对象取出来传递给其它地方使用， 只能在Fresco提供的作用域范围内使用。
实际项目中会获取缓冲的文件对象：

//同样在DataSubscriber中获取
FileBinaryResource resource = (FileBinaryResource) Fresco.getImagePipelineFactory().getMainFileCache().getResource(new SimpleCacheKey(url));
if (resource != null && resource.getFile() != null) {
    setImage(ImageSource.uri(Uri.fromFile(resource.getFile())));
}
1
2
3
4
5
优点
Glide

多种图片格式的缓存，适用于更多的内容表现形式（如Gif、WebP、缩略图、Video）
生命周期集成（根据Activity或者Fragment的生命周期管理图片加载请求）
高效处理Bitmap（bitmap的复用和主动回收，减少系统回收压力）
高效的缓存策略，灵活（Picasso只会缓存原始尺寸的图片，Glide缓存的是多种规格），加载速度快且内存开销小（默认Bitmap格式的不同，使得内存开销是Picasso的一半）
Fresco

最大的优势在于5.0以下(最低2.3)的bitmap加载。在5.0以下系统，Fresco将图片放到一个特别的内存区域(Ashmem区)
大大减少OOM（在更底层的Native层对OOM进行处理，图片将不再占用App的内存）
适用于需要高性能加载大量图片的场景
缺点
Glide

-没有文件缓存
-java heap比Fresco高

Fresco

包较大（2~3M）
用法复杂
底层涉及c++领域，阅读源码深入学习难度大
* */