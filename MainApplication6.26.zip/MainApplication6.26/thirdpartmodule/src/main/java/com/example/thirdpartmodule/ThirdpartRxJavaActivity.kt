package com.example.thirdpartmodule

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.support.annotation.MainThread
import android.util.Log
import com.alibaba.fastjson.serializer.AfterFilter
import com.example.basemodule.base.BaseActivity
import io.reactivex.*
import io.reactivex.Observable
import io.reactivex.Observer
import io.reactivex.android.plugins.RxAndroidPlugins
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.functions.Action
import io.reactivex.functions.Consumer
import io.reactivex.schedulers.Schedulers
import java.util.concurrent.TimeUnit
import javax.xml.datatype.DatatypeConstants.SECONDS
import io.reactivex.internal.disposables.DisposableHelper.isDisposed
import io.reactivex.disposables.Disposable
import io.reactivex.functions.Function
import io.reactivex.subjects.Subject
import java.util.*
import io.reactivex.subjects.PublishSubject




// https://blog.csdn.net/maplejaw_/article/details/52442065
// https://www.jianshu.com/p/464fa025229e
//https://www.jianshu.com/p/0cd258eecf60
// https://github.com/amitshekhariitbhu/RxJava2-Android-Samples
class ThirdpartRxJavaActivity : BaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_thirdpart_rx_java
    }

    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_thirdpart_rx_java)
        setTitle("RxJava2")
        test6()
    }

    // just
    fun test1()
    {
        // just
//        Observable.just("1").subscribe(Consumer<String>{ it
//            Log.v("puny",it)
//        })
//        Observable.just("2","3").subscribe(Consumer<String> { it
//            Log.v("puny",it)
//        })
        val observable:Observable<String> = Observable.just("hello")
        observable.subscribe(Consumer<String> { it ->
            Log.v("puny",it)
        })
//        val observable:Observable<String> = Observable.just("hello").repeat()
//        observable.subscribe(Consumer<String> { it ->
//            Log.v("puny",it)
//        })
    }

    // interval
    fun test2() {
        // 间隔2s的定时器
//        val observable = Observable.interval(2, TimeUnit.SECONDS)
//        observable.subscribe(Consumer<Long> { it ->
//            // 0 1 2 3 4 5 ....
//            Log.v("puny",it.toString())
//        })

        val observable = Observable.interval(2, TimeUnit.SECONDS)
        observable.subscribe(Consumer<Long> { it ->
            // 0 1 2 3 4 5 ....
            Log.v("puny",it.toString() + Thread.currentThread().name)
        })

    }

    // range (1-20)
    fun test3()
    {
        /*创建一个发射特定整数序列的Observable，第一个参数为起始值，第二个为发送的个数，如果为0则不发送，负数则抛异常。上述表示发射1到20的数。即调用20次nNext()方法，依次传入1-20数字。*/
        val observable = Observable.range(1,20)
        observable.subscribe(Consumer<Int> { it ->
            // 1 2 3 4 5 ....20
            Log.v("puny",it.toString() + Thread.currentThread().name)
        })
    }

    // timer 延时2s 执行
    fun test4() {
        val observable = Observable.timer(2, TimeUnit.SECONDS)
//        observable.subscribe(Consumer<Long> { it ->
//            // 0
//            Log.v("puny",it.toString() + Thread.currentThread().name)
//        })
        // 在哪个线程发送事件
//        observable.subscribeOn(AndroidSchedulers.mainThread()).subscribe { it ->
//            Log.v("puny",it.toString() + Thread.currentThread().name)
//        }
        // 在哪个线程观察【主线程】
//        observable.observeOn(AndroidSchedulers.mainThread()).subscribe { it ->
//            Log.v("puny",it.toString() + Thread.currentThread().name)
//        }

        // 在哪个线程观察【主线程】
//        observable.observeOn(AndroidSchedulers.from(Looper.getMainLooper())).subscribe { it ->
//            Log.v("puny",it.toString() + Thread.currentThread().name)
//        }

        // 0RxNewThreadScheduler 子线程
//        observable.observeOn(Schedulers.newThread()).subscribe { it ->
//            Log.v("puny",it.toString() + Thread.currentThread().name)
//        }

        // 0RxComputationThreadPool 子线程 计算线程
//        observable.observeOn(Schedulers.computation()).subscribe { it ->
//            Log.v("puny",it.toString() + Thread.currentThread().name)
//        }

        observable.observeOn(AndroidSchedulers.mainThread()).subscribe { it ->
            Log.v("puny",it.toString() + Thread.currentThread().name)
        }
    }


    /*
    *     //使用RxJava处理
    Observable.create(ObservableOnSubscribe<String> {
        e ->

        //使用okhttp3访问网络
        val builder = Request.Builder()
        val request = builder.url(NEWS_URL).get().build()
        val response = client.newCall(request).execute()
        val responseBody = response.body()
        val result = responseBody?.string()
        //这里的.string()只能用一次  如果下面那一句不注释的话就会报错
        //val result2 = responseBody?.string()

        Log.e(TAG, result)

        //这里其实形参是String类型,然而实参是String?类型,如果直接传result会报错,在后面加!!即可解决
        //发射(这里是被观察者,被观察者发射事件)
        e.onNext(result!!)

        //上面那句代码可以这样写
        //e.onNext(result as String)
    }).subscribeOn(Schedulers.io())  //io线程  被观察者
            .observeOn(AndroidSchedulers.mainThread())  //主线程 观察者
            .subscribe({

                //这里接收刚刚被观察者发射的事件
                //这个response就是io线程发射过来的result
                response ->
                Log.e(TAG, response)
            })
            */
    // Observable.create 完整写法
    fun test5() {
        val observable = Observable.create(ObservableOnSubscribe<String> {it
            it.onNext("next data  ")
//            it.onError(Throwable("hhhh  "))
            it.onComplete()
        })

        // 只接受一种事件
//        observable.subscribe(Consumer<String> { it
//            Log.v("puny",it.toString() + Thread.currentThread().name)
//        })

        // 只接受一种事件
//        observable.subscribe({
//            it ->
//            Log.v("puny",it.toString() + Thread.currentThread().name)
//        })

//        observable.subscribe(Consumer<String>{it
//            Log.v("puny",it.toString() + Thread.currentThread().name)
//        }, Consumer<Throwable> { t ->
//            Log.v("puny",t.toString() + Thread.currentThread().name)
//        })

//        observable.subscribe(Consumer<String>{it
//            Log.v("puny",it.toString() + Thread.currentThread().name)
//        }, Consumer<Throwable> { t ->
//            Log.v("puny",t.toString() + Thread.currentThread().name)
//        })

        observable.subscribe(Consumer<String>{it
            Log.v("puny",it.toString() + Thread.currentThread().name)
        }, Consumer<Throwable> { t ->
            Log.v("puny",t.toString() + Thread.currentThread().name)
        }, Action {
            Log.v("puny","completed")
        })
    }

    private fun getObservable(): Observable<Int> {
        return Observable.just(1, 2, 3, 4, 5)
    }

    private fun getObserver(): Observer<Int> {
        return object : Observer<Int> {
            override fun onNext(t: Int) {
                Log.d("puny", t.toString())
            }

            override fun onSubscribe(d: Disposable) {
                Log.d("puny", " onSubscribe : " + d.isDisposed)
            }

            override fun onError(e: Throwable) {
                Log.d("puny", " onError : " + e.message)
            }

            override fun onComplete() {

                Log.d("puny", " onComplete")
            }
        }
    }

    // take
    fun test66() {

//        getObservable().take(3).subscribe { it ->
//            Log.v("puny",it.toString())
//        }

        //  getObserver 另一种写法
//        getObservable().subscribeWith(getObserver())
        getObservable().subscribeWith(object : Observer<Int> {
            override fun onNext(t: Int) {
                Log.d("puny", t.toString())
            }

            override fun onSubscribe(d: Disposable) {
                Log.d("puny", " onSubscribe : " + d.isDisposed)
            }

            override fun onError(e: Throwable) {
                Log.d("puny", " onError : " + e.message)
            }

            override fun onComplete() {

                Log.d("puny", " onComplete")
            }
        })
    }

    // take
    fun test67() {
//                getObservable().take(3).subscribe { it ->
//            Log.v("puny",it.toString())
//        }
        getObservable()
                // Run on a background thread
                .subscribeOn(Schedulers.io())
                // Be notified on the main thread
                .observeOn(AndroidSchedulers.mainThread())
                .take(3)
                .subscribe(getObserver())
    }

    // skip
    fun test68() {
        getObservable().skip(2).subscribeWith(getObserver())
    }

    // empty,onSubscribe和onComplete方法会执行
    fun test69() {
        /*
        * 06-12 14:49:51.114 8812-8812/com.example.zhangyuanke.mainapplication D/puny:  onSubscribe : true
06-12 14:49:51.114 8812-8812/com.example.zhangyuanke.mainapplication D/puny:  onComplete
*/
        Observable.empty<Int>().subscribeWith(getObserver())
        Observable.empty<Int>().subscribeWith(getObserver())
    }

    // map
    fun test60() {
//        getObservable().map{ "123" }.subscribe { it
//            Log.d("puny", it)
//        }


//        getObservable().map{ittemp->
//            return@map ittemp.toString() + ":abc"
//        }.subscribe { it
//            Log.d("puny", it)
//        }

//        getObservable().map{
//            it % 2 == 0
//        }.subscribe {
//            Log.d("puny", it.toString())
//        }

        getObservable().map{
            it % 2 == 0
        }.subscribe {
            Log.d("puny", it.toString())
        }
    }

    // filter
    fun test622() {
        getObservable().filter{
            it % 2 == 0
        }.subscribe {
            Log.d("puny", it.toString())
        }

        // 重试
//        getObservable().retry(3).subscribe()
//        getObservable().flatMap {  }
    }

    /*
    * 关于disposable
rxjava虽然好用，但是总所周知，容易遭层内存泄漏。也就说在订阅了事件后没有及时取阅，导致在activity或者fragment销毁后仍然占用着内存，无法释放。而disposable便是这个订阅事件，可以用来取消订阅。但是在什么时候取消订阅呢？我知道有两种方式:

使用CompositeDisposable

Disposable类:

dispose():主动解除订阅
isDisposed():查询是否解除订阅 true 代表 已经解除订阅
CompositeDisposable类:可以快速解除所有添加的Disposable类 每当我们得到一个Disposable时就调用CompositeDisposable.add()将它添加到容器中, 在退出的时候, 调用CompositeDisposable.clear() 即可快速解除.

*/

    fun test699()
    {
        val disposable =  getObservable().subscribe {
            Log.d("puny", it.toString())
        }
//        disposable.dispose()
        val dis = CompositeDisposable()
        dis.add(disposable)
        dis.dispose()
        dis.clear()
    }

    private fun getObservable22(): Observable<Int> {
        return Observable.just(1, 2)
    }


    /**定义一个函数*/
    fun makeFun():() -> Unit{
        var count = 0
        //返回一个匿名函数，打印一下
        return fun(){
            println(++count)
        }
    }


    // 闭包表达式使用
    // 闭包表达式使用
    // 闭包表达式使用
    // 闭包表达式使用

    // 闭包表达式使用
    fun test600()
    {
//        val cal:(Int) -> Unit = {
//            Log.d("puny", it.toString())
//        }
        // 闭包2
//        val cal2 = { x: Int, y: Int ->
////            println("${x + y}")
//            Log.d("puny", "${x + y}")
//        }
//
//        cal2(10,20)

        // 闭包3
//        val cal3:(Int,Int)->Int = { i: Int, i1: Int ->
//            10 + 20
//            20+30
//            30+30
//        }
//        val dd = cal3(10,10)
//        Log.d("puny", "${dd}")

        // 闭包4
//        val cal3:(Int,Int)->Int = { i: Int, i1: Int ->
//            i + i1
//        }
//        val dd = cal3(10,10)
//        Log.d("puny", "${dd}")

        // 闭包5
//        val cal5:(Int)->String = { i: Int ->
//            "${i}"
//            "${i}"
//            "${i + 40}"
//// 最后一行未lambda的返回值
//        }
//        val dd = cal5(10)
//        Log.d("puny", "${dd}")

        // 闭包6
//        val cal6 = { i: Int ->
//             i * 2
//                i+ 2
//            "${i + 40}" + "abcdef"
//// 最后一行未lambda的返回值
//        }
//        val dd = cal6(10)
//        Log.d("puny", "${dd}")


        // 返回一个信号
//        val myTest = { it:Int ->
//            Observable.just(it)
//        }
//
//        myTest(10).subscribe {
//            Log.d("puny", "${it}")
//        }

        val myTest = {it:Int ->

        }

    }

    // 热信号
    fun test6()
    {
        // 非热信号，还是冷信号
        /*
        val v = Subject.create<String> {
            it.onNext("123")
            it.onNext("345")
            it.onComplete()

            // 延时执行
            Handler().postDelayed(Runnable {
                kotlin.run {
                    it.onNext("789")
                }
            },3000
            )

        }
        v.subscribe {
            Log.d("puny", "${it}")
        }

//        延时订阅
        Handler().postDelayed(Runnable {
            kotlin.run {
                v.subscribe {
                    Log.d("puny", "${it}")
                }
            }
        },2000)
        */

        // 这个才是热信号
        doSomeWork()
    }

    /* PublishSubject emits to an observer only those items that are emitted
     * by the source Observable, subsequent to the time of the subscription.
     */
    private fun doSomeWork() {

        val source = PublishSubject.create<Int>()

        source.subscribe({
            Log.d("puny", "${it}" + "   abc")
        }) // it will get 1, 2, 3, 4 and onComplete

        source.onNext(1)
        source.onNext(2)
        source.onNext(3)

        /*
         * it will emit 4 and onComplete for second observer also.
         */
        source.subscribe({
            Log.d("puny", "${it}" + "   def")
        })

        source.onNext(4)
        source.onComplete()

    }

}
