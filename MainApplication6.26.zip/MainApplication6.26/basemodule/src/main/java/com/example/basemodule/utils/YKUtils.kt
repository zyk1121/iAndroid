package com.example.basemodule.utils

import android.os.Handler
import android.util.Log

/**
 * Created by zhangyuanke on 2018/6/17.
 */

public class YKUtils {

    // 静态方法和变量
    companion object {
        // 延时执行
        public fun after(duration:Long, completion:(()->Unit)?) {
            Handler().postDelayed(Runnable {
                kotlin.run {
                    if (completion != null) {
                        completion()
                    }
                }
            },duration)
        }

        // 测试闭包
        public fun testBlock(duration:Long, completion: (x:Int,y:Int) -> Int) {
            Handler().postDelayed(Runnable {
                kotlin.run {
                    if (completion != null) {
                        val sum = completion(10,20)
                        Log.d("puny", "x * y = ${sum}")
                        print(sum)
                    }
                }
            },duration)
        }
        // 测试闭包
        public fun testBlock2(duration:Long, completion: ((x:Int,y:Int) -> Int)?) {
            Handler().postDelayed(Runnable {
                kotlin.run {
                    if (completion != null) {
                        val sum = completion(10,20)
                        Log.d("puny", "x * y = ${sum}")
                        print(sum)
                    }
                }
            },duration)
        }
        /*
        *  // 测试闭包

//        YKUtils.testBlock(3000, completion = {x:Int,y:Int ->
//                val s= x+y
//            Log.d("puny", "x+y= ${s}")
//                x*y
//            // 最后一行代码是返回值
//            x*y
//            })

        YKUtils.testBlock(3000, {x:Int,y:Int ->
            val s= x+y
            Log.d("puny", "x+y= ${s}")
            x*y
            // 最后一行代码是返回值
            x*y
        })

        YKUtils.testBlock2(5000, {x:Int,y:Int ->
            val s= x-y
            Log.d("puny", "x-y= ${s}")
            x*y
            // 最后一行代码是返回值
            x*y
        })
        YKUtils.testBlock2(3000, null)
        */
    }
}