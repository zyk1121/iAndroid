package com.example.zhangyuanke.mainapplication

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import butterknife.ButterKnife
import butterknife.OnClick
import com.example.basemodule.base.BaseActivity
import com.example.firstcodemodule.FirstcodeActivityMainActivity
import com.example.frameworkmodule.FrameworkMainActivity
import com.example.thirdpartmodule.ThirdpartMainActivity
import com.example.uilayoutmodule.UILayoutMainActivity
import com.example.zhangyuanke.mainapplication.test.TestActivity
import com.githang.statusbar.StatusBarCompat

class MainActivity : BaseActivity() {
    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_main
    }

    private var listView:ListView? = null

    public var listDatas:Array<String> =
            arrayOf(
                    "1、基础知识",
                    "2、常用UI布局",
                    "3、第三方框架",
                    "4、基础架构",
                    "5、NDK",
                    "6、性能 & 源码",
                    "7、发布 & 其他")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ButterKnife.bind(this)
        setTitle("Android代码")
        hideLeftBarButtonItem()

//        setContentView(R.layout.activity_main)
        listView = findViewById(R.id.main_list_view)
        listView?.adapter = MyListAdapter(this)
//        listView?.setOnItemClickListener { parent, view, position, id -> Toast.makeText(this,"cecshi",Toast.LENGTH_SHORT).show() }
//        listView?.setOnItemClickListener { parent, view, position, id ->  {
//            Toast.makeText(this,"cecshi22",Toast.LENGTH_SHORT).show()
//        }()}
//        listView?.setOnItemClickListener(this)

        listView?.setOnItemClickListener { parent, view, position, id ->
            {
//                Toast.makeText(this, listDatas.get(position), Toast.LENGTH_SHORT).show()
                onItemClick(position)
            }()
        }

//        var arr:Array<String> = arrayOf("1","2")
//        var l:List<String> = listOf()
//        var m:Map<String,String> = mapOf()
//        var s:Set<Int> = setOf()
//        listView?.setOnItemClickListener { parent, view, position, id -> onItemClick(position) }
    }

    // 点击了某个cell
    fun onItemClick(position: Int) {
        val intent = Intent()
        intent.setClass(this, TestActivity::class.java)
        when (position) {
            0 -> intent.setClass(this,FirstcodeActivityMainActivity::class.java)
            1 -> intent.setClass(this,UILayoutMainActivity::class.java)
            2 -> intent.setClass(this,ThirdpartMainActivity::class.java)
            3 -> intent.setClass(this,FrameworkMainActivity::class.java)
        }

        startActivity(intent)

        // 暂时不能用，Kotlin还不支持ARouter，Java是ok的
//        ARouter.getInstance().build("/main/test").navigation()
        /*
        val intent = Intent()
        //获取intent对象
        intent.setClass(this,TestJavaActivity::class.java)
        // 获取class是使用::反射
        startActivity(intent)
        */

//        ARouter.getInstance().build("/main/test").navigation()
//        when (position) {
//            0 ->  ARouter.getInstance().build("/firstcode/main").navigation()
//            0 -> {Log.v("puny","打印1"); Log.v("puny","打印2"); Log.v("puny","打印3")}
//            1 -> {Log.v("puny","打印1"); Log.v("puny","打印2"); Log.v("puny","打印3")}
//        }
        /*
        *  // 1. 应用内简单的跳转(通过URL跳转在'进阶用法'中)
        ARouter.getInstance().build("/test2/testActivity2").navigation();

// 2. 跳转并携带参数
        /*
        ARouter.getInstance().build("/test/baseActivity")
                .withLong("key1", 666L)
                .withString("key3", "888")
                .navigation();
                */
                *
                *
         val intent = Intent()
        //获取intent对象
        intent.setClass(this,FirstcodeActivityMainActivity::class.java)
        // 获取class是使用::反射
        startActivity(intent)
*/

        // test Butterknife
//        @OnClick(R.id.banner_indicator)
//        fun click(v:View) {
//
//        }
    }

    inner class MyListAdapter(tempContext:Context): BaseAdapter() {

        var context: Context = tempContext

        override fun getItem(position: Int): String {
            return listDatas.get(position)
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getCount(): Int {
            return listDatas.size
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            var viewHolder: ViewHolder
            var view: View

            if (convertView == null) {
                view = View.inflate(context, R.layout.main_item_cell, null)
                viewHolder = ViewHolder(view)
                view.setTag(viewHolder)
            } else {
                view = convertView
                viewHolder = view.getTag() as ViewHolder
            }

            viewHolder.item_cell.text = listDatas.get(position)

            return view
        }
    }

    class ViewHolder(var v: View) {
        var item_cell: TextView = v.findViewById(R.id.main_item_cell_tv)
    }
}


