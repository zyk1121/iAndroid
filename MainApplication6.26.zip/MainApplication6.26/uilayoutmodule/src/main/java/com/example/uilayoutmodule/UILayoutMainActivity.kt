package com.example.uilayoutmodule

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import com.example.basemodule.base.BaseActivity

class UILayoutMainActivity : BaseActivity() {

    override fun getLayoutId(): Int {
        return R.layout.activity_uilayout_main
    }
    override fun afterCreate(savedInstanceState: Bundle?) {
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_uilayout_main)
        setTitle("Android UI")

        listView = findViewById(R.id.uilayout_list_view)
        listView?.adapter = MyListAdapter(this)
//        listView?.setOnItemClickListener { parent, view, position, id -> Toast.makeText(this,"cecshi",Toast.LENGTH_SHORT).show() }
//        listView?.setOnItemClickListener { parent, view, position, id ->  {
//            Toast.makeText(this,"cecshi22",Toast.LENGTH_SHORT).show()
//        }()}
//        listView?.setOnItemClickListener(this)

        listView?.setOnItemClickListener { parent, view, position, id ->
            {
                //                Toast.makeText(this, listDatas.get(position), Toast.LENGTH_SHORT).show()
                onItemClick(position)
            }()
        }
    }

    private var listView: ListView? = null

    public var listDatas:Array<String> =
            arrayOf(
                    "1、对话框Dialog",
                    "2、Android动画")
    // 点击了某个cell
    fun onItemClick(position: Int) {
        val intent = Intent()
        intent.setClass(this, UICustomDialogActivity::class.java)
        when (position) {
            0 -> intent.setClass(this,UICustomDialogActivity::class.java)

        }

        startActivity(intent)

    }

    inner class MyListAdapter(tempContext: Context): BaseAdapter() {

        var context: Context = tempContext

        override fun getItem(position: Int): String {
            return listDatas.get(position)
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getCount(): Int {
            return listDatas.size
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            var viewHolder: ViewHolder
            var view: TextView

            if (convertView == null) {
                view = TextView(context)
                view.textSize = 30F
                viewHolder = ViewHolder(view)
                view.setTag(viewHolder)
            } else {
                view = convertView as TextView
                viewHolder = view.getTag() as ViewHolder
            }

            viewHolder.item_cell.text = listDatas.get(position)

            return view
        }
    }

    class ViewHolder(var v: View) {
        var item_cell: TextView = v as TextView
    }
}
