package com.example.uilayoutmodule

import android.app.Dialog
import android.content.Context
import android.os.Bundle

/**
 * Created by zhangyuanke on 2018/6/17.
 */

// https://www.cnblogs.com/holyday/p/7284394.html
// https://blog.csdn.net/zhuwentao2150/article/details/52254579
class YKCustomDialog(context: Context):Dialog(context) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.yk_custom_dialog_layout)
    }
}