package com.example.uilayoutmodule

import android.app.AlertDialog
import android.app.Dialog
import android.app.DialogFragment
import android.app.FragmentManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.basemodule.base.BaseActivity
import android.content.DialogInterface
import android.os.Handler
import android.widget.EditText
import android.widget.ImageView


// https://www.jianshu.com/p/64446940eccf
// https://blog.csdn.net/Daxue_haha/article/details/53516519
class UICustomDialogActivity : BaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_uicustom_dialog
    }

    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_uicustom_dialog)
        setTitle("Dialog")
        toastTest()
    }

    private fun showExitDialog01() {
        AlertDialog.Builder(this)
                .setTitle("标题")
                .setMessage("简单的消息提示框")
                .setPositiveButton("确定", null)
                .show()
    }

    fun toastTest()
    {
        Toast.makeText(this,"toast test",Toast.LENGTH_SHORT).show()

        Handler().postDelayed({
//            dialogTest()
//            showExitDialog01()
//            showExitDialog07()
//            MyDialogFragment().show(fragmentManager,"ddddd")

            showCustomDialog()
        },3000)
    }

    fun showCustomDialog() {
        val dialog = YKCustomDialog(this)
        dialog.show()
    }

    // https://blog.csdn.net/zhuwentao2150/article/details/51478053

    // 可输入文本的提示框
    private fun showExitDialog03() {
        val edt = EditText(this)
        edt.minLines = 3
        AlertDialog.Builder(this)
                .setTitle("请输入")
                .setIcon(android.R.drawable.ic_dialog_info)
                .setView(edt)
                .setNegativeButton("取消", null)
                .show()
    }

    // 显示图片的对话框
    private fun showExitDialog07() {
        val img = ImageView(this)
        img.setImageResource(R.drawable.icon11)
        AlertDialog.Builder(this)
                .setTitle("图片框")
                .setView(img)
                .setPositiveButton("确定", null)
                .show()
    }

    fun dialogTest()
    {
        //dialog参数设置
//        val builder = AlertDialog.Builder(this)  //先得到构造器
//        builder.setTitle("请选择") //设置标题
//        builder.setMessage("是否确认退出?"); //设置内容
//        builder.setIcon(R.drawable.icon10);//设置图标，图片id即可
//        //设置列表显示，注意设置了列表显示就不要设置builder.setMessage()了，否则列表不起作用。
//        val items = arrayOf<String>("确认","取消")
//        builder.setItems(items, DialogInterface.OnClickListener { dialog, which ->
//            dialog.dismiss()
//        })
////        builder.create()
//        builder.create().show()

        val builder = AlertDialog.Builder(this)  //先得到构造器
        builder.setTitle("请选择") //设置标题
        builder.setMessage("是否确认退出?"); //设置内容
        builder.setIcon(R.drawable.icon10);//设置图标，图片id即可
        //设置列表显示，注意设置了列表显示就不要设置builder.setMessage()了，否则列表不起作用。
//        val items = arrayOf<String>("确认","取消")
//        builder.setItems(items, DialogInterface.OnClickListener { dialog, which ->
//            dialog.dismiss()
//        })
//        builder.create()
        builder.setCancelable(false)// 点击其他区域消失

        builder.setPositiveButton("OK",DialogInterface.OnClickListener { dialog, which ->
            dialog.dismiss()
        })
        builder.setNegativeButton("cancel",DialogInterface.OnClickListener { dialog, which ->
            dialog.dismiss()
        })
        builder.create().show()
    }
}

// 自定义对话框 AlertDialog.Builder(getA
class MyDialogFragment : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle): Dialog {
        val builder = AlertDialog.Builder(getActivity())
        builder.setTitle("title")
                .setMessage("message")
                .setPositiveButton("确定") { dialog, id ->
                    dialog.dismiss()
                }
                .setNegativeButton("取消") { dialog, id ->
                    dialog.dismiss()
                }
        return builder.create()
    }

}