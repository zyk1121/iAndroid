package com.example.firstcodemodule

import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.util.Log
import android.view.ContextMenu
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.view.ViewGroup
import android.text.method.TextKeyListener.clear



/**
 * Created by zhangyuanke on 2018/6/6.
 */

// 看父类的构造方法：this(context, null);
class FirstcodeIndicator(context: Context,attrs:AttributeSet):LinearLayout(context,attrs) {
    private var mMarginLeft = 20//px
    private var mNum: Int = 0
    private var imageViews:MutableList<ImageView> = mutableListOf()
    init {
        setOrientation(HORIZONTAL)
//        setBackgroundColor(Color.TRANSPARENT)
        this.gravity = Gravity.CENTER
        setIndicatorViewNum(5)
    }

    /**
     * 设置指示点的间距
     *
     * @param marginLeft
     */
    fun setMarginLeft(marginLeft: Int) {
        mMarginLeft = marginLeft
    }


    /**
     * 设置indicator指示点的个数以及初始化
     *
     * @param num
     */
    fun setIndicatorViewNum(num: Int) {
        removeAllViews()
//        imageViews.add(ImageView(this.context))
//        imageViews.removeAll {
//            return@removeAll true
//        }
        imageViews.removeAll { return@removeAll true }
//        Log.v("puny","imageViews size:" + imageViews.size)
        mNum = num
//        Log.v("puny","mNum:" + mNum)
        for (i in 0 until num) {
            val imageView = ImageView(this.context)
            val params = LinearLayout.LayoutParams(30, 30)
            if (i == 0) {
                imageView.setImageResource(R.drawable.firstcode_banner_select)
            } else {
                params.leftMargin = mMarginLeft
                imageView.setImageResource(R.drawable.firstcode_banner_normal)
            }
            imageViews.add(imageView)
            addView(imageView, params)
        }
//        Log.v("puny","imageViews size:" + imageViews.size)
    }

    /**
     * 设置当前index的位置
     *
     * @param index
     */
    fun setCurrentIndex(index: Int) {
//        Log.v("puny","count:" + imageViews.size)
        for (i in 0 until mNum) {
            if (i == index) {
                imageViews[i].setImageResource(R.drawable.firstcode_banner_select)
            } else {
                imageViews[i].setImageResource(R.drawable.firstcode_banner_normal)
            }
        }
    }
}

//class FirstcodeIndicator(context: Context):LinearLayout(context) {
//    constructor(context: Context,attrs:AttributeSet):this(context) {
//        Log.v("puny","111")
//    }
//    constructor(context: Context,attrs:AttributeSet,defStyleAttr:Int):this(context) {
//        Log.v("puny","222")
//    }
//    init {
//        setOrientation(HORIZONTAL);
//        setGravity(Gravity.CENTER);
//        setBackgroundColor(Color.RED)
//    }
//
//}

// 测试继承关系

/*
Log.v("puny","类的继承关系，以及构造方法开始：")
        val test = TestStudent("5年级", "zyk", 30)

* 06-07 13:42:29.215 3785-3785/com.example.zhangyuanke.mainapplication V/puny: 类的继承关系，以及构造方法开始：
06-07 13:42:29.216 3785-3785/com.example.zhangyuanke.mainapplication V/puny: TestPerson init name:testname
06-07 13:42:29.216 3785-3785/com.example.zhangyuanke.mainapplication V/puny: TestPerson constructor name:testname age:18
06-07 13:42:29.216 3785-3785/com.example.zhangyuanke.mainapplication V/puny: TestStudent init grade:5年级
06-07 13:42:29.216 3785-3785/com.example.zhangyuanke.mainapplication V/puny: TestStudent constructor grade name age
06-07 13:42:29.515 3785-3785/com.example.zhangyuanke.mainapplication V/puny: newPosition:0
06-07 13:42:29.516 3785-3785/com.example.zhangyuanke.mainapplication V/puny: newPosition:1
*/
open class TestPerson(name:String) {
    constructor(name:String,age:Int):this(name) {
        Log.v("puny","TestPerson constructor name:" + name + " age:"+ age)
    }
    init {
        Log.v("puny","TestPerson init name:" + name)
    }
}

class TestStudent(grade:String):TestPerson("testname",18) {
    constructor(grade:String,name: String,age: Int):this(grade) {
        Log.v("puny","TestStudent constructor grade name age")
    }
    constructor(name: String,age: Int):this("3年级") {
        Log.v("puny","TestStudent constructor name age")
    }
    init {
        Log.v("puny","TestStudent init grade:" + grade)
    }
}




//class FirstcodeIndicator: LinearLayout() {
//    fun FirstcodeIndicator(context:Context)
//    {
//        this(context, null)
//    }
//
//    fun FirstcodeIndicator(context:Context, attrs:AttributeSet)
//    {
//        this(context, attrs, 0);
//    }
//
//    fun FirstcodeIndicator(context:Context,  attrs:AttributeSet, defStyleAttr:Int)
//    {
//        super(context, attrs, defStyleAttr);
//        init();
//    }
//    fun init()
//    {
//        setOrientation(HORIZONTAL);
//        setGravity(Gravity.CENTER);
//    }
//}
//    private int mMarginLeft = 20;//px
//    private int mNum;
//    private List<ImageView> imageViews = new ArrayList<>();
//
//    public ViewIndicator(Context context)
//    {
//        this(context, null);
//    }
//
//    public ViewIndicator(Context context, AttributeSet attrs)
//    {
//        this(context, attrs, 0);
//    }
//
//    public ViewIndicator(Context context, AttributeSet attrs, int defStyleAttr)
//    {
//        super(context, attrs, defStyleAttr);
//        init();
//    }
//
//    private void init()
//    {
//        setOrientation(HORIZONTAL);
//        setGravity(Gravity.CENTER);
//    }
//
//    /**
//     * 设置指示点的间距
//     *
//     * @param marginLeft
//     */
//    public void setMarginLeft(int marginLeft)
//    {
//        mMarginLeft = marginLeft;
//    }
//
//
//    /**
//     * 设置indicator指示点的个数以及初始化
//     *
//     * @param num
//     */
//    public void setIndicatorViewNum(int num)
//    {
//        removeAllViews();
//        imageViews.clear();
//        mNum = num;
//        for (int i = 0; i < num; i++) {
//        ImageView imageView = new ImageView(this.getContext());
//        LinearLayout.LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//        if (i == 0) {
//            imageView.setImageResource(R.drawable.circle_bg);
//        } else {
//            params.leftMargin = mMarginLeft;
//            imageView.setImageResource(R.drawable.circle_bg1);
//        }
//        imageViews.add(imageView);
//        addView(imageView, params);
//    }
//    }
//
//    /**
//     * 设置当前index的位置
//     *
//     * @param index
//     */
//    public void setCurrentIndex(int index)
//    {
//        for (int i = 0; i < mNum; i++) {
//        if (i == index) {
//            imageViews.get(i).setImageResource(R.drawable.circle_bg);
//        } else {
//            imageViews.get(i).setImageResource(R.drawable.circle_bg1);
//        }
//    }
//}