package com.example.firstcodemodule

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import android.widget.Button
import com.example.basemodule.base.BaseActivity
import okhttp3.*
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class FirstcodeNoticeActivity : BaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_firstcode_notice
    }


    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_firstcode_notice)
        setTitle("通知")
        setupUI()
    }

    lateinit var button21: Button
    lateinit var button22: Button
    lateinit var button23: Button
    lateinit var button24: Button


    fun setupUI() {
        button21 = findViewById<Button>(R.id.button21)
        button21.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button22 = findViewById<Button>(R.id.button22)
        button22.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button23 = findViewById<Button>(R.id.button23)
        button23.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button24 = findViewById<Button>(R.id.button24)
        button24.setOnClickListener { it ->
            buttonClick(it as Button)
        }
    }


    fun buttonClick(button: Button) {
//        Toast.makeText(this,"button click:" + button.id.toString(),Toast.LENGTH_SHORT).show()
        when (button.id) {
            R.id.button21 -> {
//                sendNotice()
            }
            R.id.button22 -> {
                threadTest()
            }
            R.id.button23 -> {
                serviceTest()
            }
            R.id.button24 -> {
                Thread(Runnable { kotlin.run {

                    httpTest()
//                    httpTest2()

                } }).start()

            }
        }
    }

    // https://blog.csdn.net/yoonerloop/article/details/79000125
    fun httpTest(){
        Log.v("puny","data:httpTest")
        // https://blog.csdn.net/yoonerloop/article/details/79000125
        val client= OkHttpClient()
        val request =  Request.Builder().get().url("http://192.168.0.3:8080/test.json").build()
//        val request =  Request.Builder().get().url("http://www.baidu.com").build()
        //构造Request对象
        //采用建造者模式，链式调用指明进行Get请求,传入Get的请求地址
        val call = client.newCall(request)
        //异步调用并设置回调函数

        call.enqueue(object:Callback {
            override fun onFailure(call: Call?, e: IOException?) {
                Log.v("puny","data:onFailure")
            }

            override fun onResponse(call: Call?, response: Response?) {
                Log.v("puny","data:" + response.toString())
                Log.v("puny","data:" + response!!.body())
            }
        })


    }

    fun httpTest2()
    {
        val url = URL("http://www.baidu.com")
        var httpConnect = url.openConnection() as HttpURLConnection
        try {
//            connection.requestMethod = "GET"
//            connection.connectTimeout = 8000
//            connection.readTimeout = 8000
//            connection.connect()
//            val input = connection.inputStream
//            val reader = BufferedReader(InputStreamReader(input))
//            var response = StringBuilder()
//            var line:String? = null
//            line = reader.readLine()
//            while (line != null) {
////                Log.v("puny","data:" + line)
//                response.append(line)
//                line = reader.readLine()
//            }
//            Log.v("puny","data:" + response)

            httpConnect.connectTimeout = 5 * 1000  // 设置连接超时时间
            httpConnect.readTimeout = 5 * 1000  //设置从主机读取数据超时
            httpConnect.doOutput = true
            httpConnect.doInput = true
            httpConnect.useCaches = false
            httpConnect.requestMethod = "GET" // 设置为Post请求
            httpConnect.connect() // 开始连接

            var inputStream = httpConnect.inputStream
            var reader = BufferedReader(InputStreamReader(inputStream))
//            var str: String = ""
//            while ((str = reader.readLine()) != null) {
//                println(str)
//            }
            var strBuilder = StringBuilder()
            reader.forEachLine {
                strBuilder.append(it)
                Log.v("puny","data:" + it)
            }
        } catch (e:Exception) {
            e.printStackTrace()
        } finally {
            httpConnect.disconnect()
        }

    }

    fun serviceTest()
    {
        val intent = Intent(this,MyService::class.java)
        startService(intent)
    }


    fun threadTest()
    {
        // 写法1
//        Thread(Runnable { kotlin.run {
//            Log.v("puny","Thread Runnable run 1:" + Thread.currentThread().name)
//        } }).start()

        // 写法2
//        MyThread().start()
        // 写法3
//        val thread = Thread(MyThread2())
//        thread.start()
        val thread = Thread(Runnable { kotlin.run {
            Log.v("puny","Thread Runnable run 写法简单:" + Thread.currentThread().name)
        } })
        thread.start()
    }

    fun sendNotice()
    {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = Notification(R.drawable.tab_three_select,"this is a test text",System.currentTimeMillis()) as Notification
        manager.notify(1,notification)
    }
}

class MyThread:Thread(){
    override fun run() {
        Log.v("puny","MyThread Runnable run 2:" + Thread.currentThread().name)
    }
}

class MyThread2:Runnable {
    override fun run() {
        Log.v("puny","MyThread2 Runnable run 3:" + Thread.currentThread().name)
    }
}

class MyService:Service(){
    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        Log.v("puny","MyService onCreate")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return super.onStartCommand(intent, flags, startId)
        Log.v("puny","MyService onStartCommand")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.v("puny","MyService onDestroy")
    }

}
