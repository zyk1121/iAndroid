package com.example.firstcodemodule

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.content.LocalBroadcastManager
import android.view.View
import android.widget.Button
import android.widget.Toast
import com.example.basemodule.base.BaseActivity

class FirstcodeBrodecastReceiveActivity : BaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_firstcode_brodecast_receive
    }

    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    lateinit var button4:Button
    lateinit var button5:Button
    lateinit var button6:Button

    lateinit var button8:Button
    lateinit var button7:Button

    lateinit var button9:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_firstcode_brodecast_receive)
        setTitle("广播接收器")
        setupUI()
    }

    fun setupUI()
    {
        button4 = findViewById<Button>(R.id.button4)
        button5 = findViewById<Button>(R.id.button5)
        button6 = findViewById<Button>(R.id.button6)

        button8 = findViewById<Button>(R.id.button8)
        button7 = findViewById<Button>(R.id.button7)

        button9 = findViewById<Button>(R.id.button9)

        button4.setOnClickListener {it ->
            buttonClick(it as Button)
        }
        button5.setOnClickListener {it ->
            buttonClick(it as Button)
        }
        button6.setOnClickListener {it ->
            buttonClick(it as Button)
        }
        button8.setOnClickListener {it ->
            buttonClick(it as Button)
        }
        button7.setOnClickListener {it ->
            buttonClick(it as Button)
        }
        button9.setOnClickListener {it ->
            buttonClick(it as Button)
        }
//        button4.setOnClickListener(View.OnClickListener { it ->
//
//        })
        createLocalBroad()
    }

    private var intentFilter: IntentFilter? = null
    private var networkChangeReceiver:NetworkChangeReceiver? = null
    fun buttonClick(button:Button) {
//        Toast.makeText(this,"button click:" + button.id.toString(),Toast.LENGTH_SHORT).show()
        when (button.id) {
            R.id.button4 -> {
                createReceiveDynamic()
            }
            R.id.button5 -> {
                createReceiveStatic()
            }
            R.id.button6 -> {
                remoiveReceiver()
            }
            R.id.button8 -> {
                sendStandardBroadcast()
            }
            R.id.button7 -> {
                sendOrderedBroadcast()
            }
            R.id.button9 -> {
                sendTest()
            }
        }
    }

    // 本地广播使用
    private var localReceeiver:LocalReceeiver? = null
    private var localBroadcastManager:LocalBroadcastManager? = null
    fun createLocalBroad()
    {
        intentFilter = IntentFilter()
        intentFilter?.addAction("com.example.firstcodemodule.localtest")
        localReceeiver = LocalReceeiver()

        localBroadcastManager = LocalBroadcastManager.getInstance(this)
        localBroadcastManager?.registerReceiver(localReceeiver,intentFilter)

//        registerReceiver(networkChangeReceiver,intentFilter)
    }

    fun sendTest()
    {
        val intent = Intent("com.example.firstcodemodule.localtest")
        localBroadcastManager?.sendBroadcast(intent)
    }

    // 发送标准广播
    fun sendStandardBroadcast()
    {
        val intent = Intent("com.example.firstcodemodule.MyBroadCast")
        sendBroadcast(intent)
    }
    // 发送有序广播
    fun sendOrderedBroadcast()
    {
        val intent = Intent("com.example.firstcodemodule.MyBroadCast")
//        sendBroadcast(intent)
        sendOrderedBroadcast(intent,"")
    }

    // 动态注册监听网络变化
    fun createReceiveDynamic()
    {
        intentFilter = IntentFilter()
        intentFilter?.addAction("android.net.conn.CONNECTIVITY_CHANGE")
        networkChangeReceiver = NetworkChangeReceiver()
        registerReceiver(networkChangeReceiver,intentFilter)

    }
    // 静态注册实现监听开机启动
    fun createReceiveStatic()
    {
        // BootCompleteReceiver
    }
    // 移除监听

    fun remoiveReceiver()
    {
        if(networkChangeReceiver != null) {
            unregisterReceiver(networkChangeReceiver)
            networkChangeReceiver = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        localBroadcastManager?.unregisterReceiver(localReceeiver)
        remoiveReceiver()
    }


}

class NetworkChangeReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        // TODO:ddd
//        Toast.makeText(context,"network changed",Toast.LENGTH_SHORT).show()
        val manager:ConnectivityManager = context?.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo:NetworkInfo = manager.activeNetworkInfo
        if (networkInfo.isAvailable) {
            Toast.makeText(context,"network isAvailable",Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context,"network 无网络",Toast.LENGTH_SHORT).show()
        }

    }

}

class BootCompleteReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        // TODO:ddd
        Toast.makeText(context,"BootCompleteReceiver",Toast.LENGTH_SHORT).show()
//        Toast.makeText(context,"network changed",Toast.LENGTH_SHORT).show()
//        val manager:ConnectivityManager = context?.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
//        val networkInfo:NetworkInfo = manager.activeNetworkInfo
//        if (networkInfo.isAvailable) {
//
//        } else {
//            Toast.makeText(context,"network 无网络",Toast.LENGTH_SHORT).show()
//        }

    }

}

class MyBroadcastReceiver:BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        Toast.makeText(context,"MyBroadcastReceiver come",Toast.LENGTH_SHORT).show()
    }
}

class LocalReceeiver:BroadcastReceiver(){
    override fun onReceive(context: Context?, intent: Intent?) {
        Toast.makeText(context,"LocalReceeiver come",Toast.LENGTH_SHORT).show()
    }
}

