package com.example.firstcodemodule

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import com.example.basemodule.base.BaseActivity


class FirstcodeActivityMainActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.firstcode_activity_main)
        setTitle("第一行代码")
        listView = findViewById(R.id.firstcode_list_view)
        listView?.adapter = MyListAdapter(this)
//        listView?.setOnItemClickListener { parent, view, position, id -> Toast.makeText(this,"cecshi",Toast.LENGTH_SHORT).show() }
//        listView?.setOnItemClickListener { parent, view, position, id ->  {
//            Toast.makeText(this,"cecshi22",Toast.LENGTH_SHORT).show()
//        }()}
//        listView?.setOnItemClickListener(this)

        listView?.setOnItemClickListener { parent, view, position, id ->
            {
                //                Toast.makeText(this, listDatas.get(position), Toast.LENGTH_SHORT).show()
                onItemClick(position)
            }()
        }

//        var arr:Array<String> = arrayOf("1","2")
//        var l:List<String> = listOf()
//        var m:Map<String,String> = mapOf()
//        var s:Set<Int> = setOf()
//        listView?.setOnItemClickListener { parent, view, position, id -> onItemClick(position) }
    }

    override fun getLayoutId(): Int {
        return R.layout.firstcode_activity_main
    }

    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    private var listView: ListView? = null

    public var listDatas:Array<String> =
            arrayOf(
                    "1、Activity生命周期",
                    "2、Fragment学习1-Tab",
                    "3、ViewPager学习",
                    "4、Timer学习",
                    "5、约束布局",
                    "6、广播接收器",
                    "7、数据存储",
                    "8、通知多媒体",
                    "9、服务 & 多线程")
    // 点击了某个cell
    fun onItemClick(position: Int) {
        val intent = Intent()
        intent.setClass(this, FirstcodeStudyActivity::class.java)
        when (position) {
            0 -> intent.setClass(this,FirstcodeStudyActivity::class.java)
            1 -> intent.setClass(this,FirstcodeTabActivity::class.java)
            2 -> intent.setClass(this,FirstcodeBannerActivity::class.java)
            3 -> intent.setClass(this,FirstcodeBannerActivity::class.java)
            4 -> intent.setClass(this,FirstcodeConstraintActivity::class.java)
            5 -> intent.setClass(this,FirstcodeBrodecastReceiveActivity::class.java)
            6 -> intent.setClass(this,FirstcodeDataActivity::class.java)
            7 -> intent.setClass(this,FirstcodeNoticeActivity::class.java)
            8 -> intent.setClass(this,FirstcodeNoticeActivity::class.java)

        }

        startActivity(intent)

    }

    inner class MyListAdapter(tempContext: Context): BaseAdapter() {

        var context: Context = tempContext

        override fun getItem(position: Int): String {
            return listDatas.get(position)
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getCount(): Int {
            return listDatas.size
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            var viewHolder: ViewHolder
            var view: TextView

            if (convertView == null) {
                view = TextView(context)
                view.textSize = 30F
                viewHolder = ViewHolder(view)
                view.setTag(viewHolder)
            } else {
                view = convertView as TextView
                viewHolder = view.getTag() as ViewHolder
            }

            viewHolder.item_cell.text = listDatas.get(position)

            return view
        }
    }

    class ViewHolder(var v: View) {
        var item_cell: TextView = v as TextView
    }
}
