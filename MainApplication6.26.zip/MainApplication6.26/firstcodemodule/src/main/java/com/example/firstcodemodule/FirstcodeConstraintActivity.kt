package com.example.firstcodemodule

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.basemodule.base.BaseActivity

class FirstcodeConstraintActivity : BaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_firstcode_constraint
    }

    // https://blog.csdn.net/zhaoyanjun6/article/details/62896784

    override fun afterCreate(savedInstanceState: Bundle?) {
//        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_firstcode_constraint)
        setTitle("约束布局学习")
    }
}
