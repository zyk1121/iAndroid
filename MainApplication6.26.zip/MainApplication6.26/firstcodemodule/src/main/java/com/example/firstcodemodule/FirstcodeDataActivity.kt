package com.example.firstcodemodule

import android.content.ContentValues
import android.content.Context
import android.content.IntentFilter
import android.content.SharedPreferences
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import com.example.basemodule.base.BaseActivity
import java.io.*

class FirstcodeDataActivity : BaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_firstcode_data
    }


    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_firstcode_data)
        setTitle("数据存储")
        setupUI()
    }

    lateinit var button10: Button
    lateinit var button11: Button
    lateinit var button12: Button
    lateinit var button13: Button

    lateinit var button14: Button
    lateinit var button15: Button
    lateinit var button16: Button
    lateinit var button17: Button
    lateinit var button18: Button
    lateinit var button19: Button
    lateinit var button20: Button


    fun setupUI() {
        button10 = findViewById<Button>(R.id.button10)
        button11 = findViewById<Button>(R.id.button11)
        button12 = findViewById<Button>(R.id.button12)
        button13 = findViewById<Button>(R.id.button13)

        button14 = findViewById<Button>(R.id.button14)
        button15 = findViewById<Button>(R.id.button15)
        button16 = findViewById<Button>(R.id.button16)
        button17 = findViewById<Button>(R.id.button17)
        button18 = findViewById<Button>(R.id.button18)
        button19 = findViewById<Button>(R.id.button19)
        button20 = findViewById<Button>(R.id.button20)

        button10.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button11.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button12.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button13.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button14.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button15.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button16.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button17.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button18.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button19.setOnClickListener { it ->
            buttonClick(it as Button)
        }
        button20.setOnClickListener { it ->
            buttonClick(it as Button)
        }
    }


    fun buttonClick(button: Button) {
//        Toast.makeText(this,"button click:" + button.id.toString(),Toast.LENGTH_SHORT).show()
        when (button.id) {
            R.id.button10 -> {
                writefile()
            }
            R.id.button11 -> {
                readfile()
            }
            R.id.button12 -> {
                writesp()
            }
            R.id.button13 -> {
                readsp()
            }
            R.id.button14 -> {
                createDB()
            }
            R.id.button15 -> {
            }
            R.id.button16 -> {
                adddbData()
            }
            R.id.button17 -> {
            }
            R.id.button18 -> {
            }
            R.id.button19 -> {
                queryData()
            }
            R.id.button20 -> {
            }
        }
    }

    private var dbHelper:MyDbHelper? = null
    // 创建数据库
    fun createDB()
    {
//        dbHelper = MyDbHelper(this,"bookstore.db", SQLiteDatabase.CursorFactory { db, masterQuery, editTable, query ->
//            return@CursorFactory null
//        },1)
//        dbHelper?.writableDatabase

        dbHelper = MyDbHelper(this,"bookstore.db", SQLiteDatabase.CursorFactory { db, masterQuery, editTable, query ->
            return@CursorFactory null
        },2)
        dbHelper?.writableDatabase

    }

    fun adddbData() {
//        val db = dbHelper?.writableDatabase
//        val value = ContentValues()
//        value.put("name","zyk")
//        value.put("author","DDD")
//        value.put("pages",454)
//        value.put("price",16.96)
//        db?.insert("book",null,value)
//
//        value.clear()
//        value.put("name","cyy")
//        value.put("author","EEE")
//        value.put("pages",510)
//        value.put("price",19.66)
//        db?.insert("book",null,value)

        // 使用事务

        val db = dbHelper?.writableDatabase
        db?.beginTransaction()
        try {
            val value = ContentValues()
            value.put("name","zyk")
            value.put("author","DDD")
            value.put("pages",454)
            value.put("price",16.96)
            db?.insert("book",null,value)
            throw NullPointerException() // 手动抛出异常
            value.clear()
            value.put("name","cyy")
            value.put("author","EEE")
            value.put("pages",510)
            value.put("price",19.66)
            db?.insert("book",null,value)
            db?.setTransactionSuccessful()
        } catch (e:Exception) {
            e.printStackTrace()
        } finally {
            db?.endTransaction()
        }

    }

    fun queryData()
    {
        val db = dbHelper?.writableDatabase
        val cursor = db?.query(false,"book",null,null,null,null,null,null,null)

        if (cursor!!.moveToNext()) {
          do {
              val name = cursor!!.getString(cursor!!.getColumnIndex("name"))
              val price = cursor!!.getDouble(cursor!!.getColumnIndex("price"))

              Log.v("puny","name:" + name + " price:" + price)
          } while (cursor!!.moveToNext())
        }
    }

    fun writefile() {
        Log.v("puny","writefile:")
        val data = "Data to save"
        var bufferWriter:BufferedWriter? = null
        try {
            val out = FileOutputStream("data",false)
            bufferWriter = BufferedWriter(OutputStreamWriter(out))
            bufferWriter.write(data)
        } catch (e:IOException) {
            e.printStackTrace()
        } finally {
            try {
                if (bufferWriter != null) {
                    bufferWriter.close()
                }
            }catch (e:IOException) {
                e.printStackTrace()
            }
        }
    }

    fun readfile() {
        Log.v("puny","readfile:")
        var reader:BufferedReader? = null
        var stringBuilder = StringBuilder()
        try {
            val input = openFileInput("data")
            reader = BufferedReader(InputStreamReader(input))
            var line:String = ""
            line = reader.readLine()
            while (line.length > 0) {
                stringBuilder.append(line)
                line = reader.readLine()
            }
            Log.v("puny","stringBuilder:" + stringBuilder.toString())
        } catch (e:IOException) {
            e.printStackTrace()
        }finally {
            if (reader != null) {
                try {
                    reader.close()
                } catch (e:IOException) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun writesp()
    {
        Log.v("puny","writesp:")
        val editor = getSharedPreferences("data", Context.MODE_PRIVATE).edit()
        editor.putString("name","Tom")
        editor.putInt("age",28)
        editor.putBoolean("married",false)
        editor.commit()
    }
    fun readsp()
    {
        Log.v("puny","readsp:")
        val pref = getSharedPreferences("data", Context.MODE_PRIVATE)
        val name = pref.getString("name","")
        val age = pref.getInt("age",0)
        val married = pref.getBoolean("married",false)
        Log.v("puny","name:" + name + " age:" + age + " married:" + married)
    }
}

// Context context, String name, CursorFactory factory, int version
class MyDbHelper(context: Context,name:String,factory:SQLiteDatabase.CursorFactory,version:Int): SQLiteOpenHelper(context,name,factory, version) {

    private var mContext:Context = context

    // 创建数据库表
    companion object  {
//        const val CREATE_TABLE:String = "create table book(" +
//                "id integer primary key autoincrement," +
//                "author text," +
//                "price real," +
//                "pages integer," +
//                "name text)"
        const val CREATE_TABLE:String = "create table book(" +
                "id integer primary key autoincrement," +
                "author text," +
                "price real," +
                "pages integer," +
                "name text," +
                "category_id integer)"

        const val CREATE_CATEGORY:String = "create table category(" +
                "id integer primary key autoincrement," +
                "category_name text," +
                "category_code integer)"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(CREATE_TABLE)
        db?.execSQL(CREATE_CATEGORY)

        Log.v("puny","onCreate db success")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        Log.v("puny","onUpgrade db success")
        when (oldVersion) {
            1,2 -> {
                db?.execSQL(CREATE_CATEGORY)
            }
            3 -> {
                db?.execSQL("alter table book add column category_id integer")
            }
        }
    }

}