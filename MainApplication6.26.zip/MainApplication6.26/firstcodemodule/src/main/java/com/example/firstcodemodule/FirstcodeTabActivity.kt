package com.example.firstcodemodule

import android.app.Activity
import android.app.Fragment
import android.app.FragmentManager
import android.app.FragmentTransaction
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ImageButton
import com.example.firstcodemodule.tabtest.AddressFragmentFirstcode
import com.example.firstcodemodule.tabtest.FriendFragmentFirstcode
import com.example.firstcodemodule.tabtest.SettingFragmentFirstcode
import com.example.firstcodemodule.tabtest.WeiXinFragmentFirstCode




class FirstcodeTabActivity : Activity(), View.OnClickListener {

//    override fun getLayoutId(): Int {
//        return R.layout.activity_firstcode_tab
//    }
//
//    override fun afterCreate(savedInstanceState: Bundle?) {
//    }

    private var mTabWeixin: LinearLayout? = null
    private var mTabFrd: LinearLayout? = null
    private var mTabAddress: LinearLayout? = null
    private var mTabSetting: LinearLayout? = null
    //底部的按钮
    private var mWeiXin: ImageButton? = null
    private var mFriend: ImageButton? = null
    private var mAddress: ImageButton? = null
    private var mSetting: ImageButton? = null
    //FragmentLayout要加载的四个Fragment
    private var weiXinFragment: WeiXinFragmentFirstCode? = null
    private var friendFragment: FriendFragmentFirstcode? = null
    private var addressFragment: AddressFragmentFirstcode? = null
    private var settingFragment: SettingFragmentFirstcode? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        /* 很好，可以用这种方式添加视图
        val headerView = layoutInflater.inflate(com.example.basemodule.R.layout.base_title_layout,null)
        val ll:LinearLayout = layoutInflater.inflate(R.layout.activity_firstcode_tab,null) as LinearLayout
        ll.addView(headerView,0)
//        ll.addView(headerView)
        setContentView(ll)
        */

        setContentView(R.layout.activity_firstcode_tab)

        initView()
        initEvents()

        setSelect(0)
    }

    private fun initView() {
        //初始化

        mTabWeixin = findViewById<View>(R.id.id_tab_weixin) as LinearLayout?
        mTabFrd = findViewById<View>(R.id.id_tab_frd) as LinearLayout?
        mTabAddress = findViewById<View>(R.id.id_tab_address) as LinearLayout?
        mTabSetting = findViewById<View>(R.id.id_tab_setting) as LinearLayout?

        mWeiXin = findViewById<View>(R.id.id_tab_weixin_img) as ImageButton?
        mFriend = findViewById<View>(R.id.id_tab_frd_img) as ImageButton?
        mAddress = findViewById<View>(R.id.id_tab_address_img) as ImageButton?
        mSetting = findViewById<View>(R.id.id_tab_setting_img) as ImageButton?

    }

    private fun initEvents() {
        mWeiXin?.setOnClickListener(this)
        mFriend?.setOnClickListener(this)
        mAddress?.setOnClickListener(this)
        mSetting?.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v!!.id) {
            R.id.id_tab_weixin_img -> setSelect(0)
            R.id.id_tab_frd_img -> setSelect(1)
            R.id.id_tab_address_img -> setSelect(2)
            R.id.id_tab_setting_img -> setSelect(3)
        }
    }

    private fun hideFragment(fragmentTransaction: FragmentTransaction) {
        if (weiXinFragment != null) {
            fragmentTransaction.hide(weiXinFragment as Fragment)
        }
        if (friendFragment != null) {
            fragmentTransaction.hide(friendFragment as Fragment)
        }
        if (addressFragment != null) {
            fragmentTransaction.hide(addressFragment as Fragment)
        }
        if (settingFragment != null) {
            fragmentTransaction.hide(settingFragment as Fragment)
        }
    }

    /*
    * 重置所有的图片，让其恢复到灰色状态
    * */
    private fun resetImage() {
        mSetting?.setImageResource(R.drawable.tab_five_normal)
        mWeiXin?.setImageResource(R.drawable.tab_one_normal)
        mAddress?.setImageResource(R.drawable.tab_three_normal)
        mFriend?.setImageResource(R.drawable.tab_four_normal)
    }

    /*
  * 设置某个Fragment
  * */
    private fun setSelect(i: Int) {
        val fm: FragmentManager = fragmentManager
        val fragmentTransaction: FragmentTransaction = fm.beginTransaction()

        //重置图片状态
        resetImage()
        hideFragment(fragmentTransaction)
        when (i) {
            0 -> {
                //设置标题
                if (weiXinFragment == null) {
                    //如果Fragment还没实例化，实例化，并在fragmentTransaction中添加
                    weiXinFragment = WeiXinFragmentFirstCode()
                    fragmentTransaction.add(R.id.id_content, weiXinFragment as Fragment)
                } else {
                    //如果已经实例化了，就显示
                    fragmentTransaction.show(weiXinFragment as Fragment)

                }
                fragmentTransaction.commit()
                //改变底部图标的状态
                mWeiXin?.setImageResource(R.drawable.tab_one_select)
            }
            1 -> {
                if (friendFragment == null) {
                    friendFragment = FriendFragmentFirstcode()
                    fragmentTransaction.add(R.id.id_content, friendFragment as Fragment)

                } else {
                    fragmentTransaction.show(friendFragment as Fragment)
                }

                fragmentTransaction.commit()
                mFriend?.setImageResource(R.drawable.tab_three_select)
            }
            2 -> {
                if (addressFragment == null) {
                    addressFragment = AddressFragmentFirstcode()
                    fragmentTransaction.add(R.id.id_content, addressFragment as Fragment)

                } else {
                    fragmentTransaction.show(addressFragment as Fragment)

                }
                fragmentTransaction.commit()
                mAddress?.setImageResource(R.drawable.tab_four_select)
            }
            3 -> {
                if (settingFragment == null) {
                    settingFragment = SettingFragmentFirstcode()
                    fragmentTransaction.add(R.id.id_content, settingFragment as Fragment)

                } else {
                    fragmentTransaction.show(settingFragment as Fragment)

                }
                fragmentTransaction.commit()
                mSetting?.setImageResource(R.drawable.tab_five_select)
            }
        }
    }
}
