package com.example.firstcodemodule

import android.app.Fragment
import android.app.FragmentManager
import android.app.FragmentTransaction
import android.os.Bundle
import android.util.Log
import com.example.basemodule.base.BaseActivity

class FirstcodeStudyActivity : BaseActivity() {
    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_firstcode_study
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_firstcode_study)
        setTitle("Activity生命周期")
        Log.v("puny","Activity onCreate")
        // 设置默认的Fragment
        setDefaultFragment()
    }

    private fun setDefaultFragment()
    {
        val fm = getFragmentManager()
        val transaction = fm.beginTransaction()
        var mTest:FirstcodeStudyBlankFragment1 = FirstcodeStudyBlankFragment1()
        transaction.replace(R.id.firstcode_study_container, mTest as Fragment)
        transaction.commit()
    }

    override fun onStart() {
        super.onStart()

        Log.v("puny","Activity onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.v("puny","Activity onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.v("puny","Activity onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.v("puny","Activity onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.v("puny","Activity onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.v("puny","Activity onDestroy")
    }


}
