package com.example.firstcodemodule

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup


/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [FirstcodeStudyBlankFragment1.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [FirstcodeStudyBlankFragment1.newInstance] factory method to
 * create an instance of this fragment.
 */
class FirstcodeStudyBlankFragment1 : Fragment() {
    /*
    * onAttach()：Fragment和Activity相关联时调用。可以通过该方法获取Activity引用，还可以通过getArguments()获取参数。
onCreate()：Fragment被创建时调用。
onCreateView()：创建Fragment的布局。
onActivityCreated()：当Activity完成onCreate()时调用。
onStart()：当Fragment可见时调用。
onResume()：当Fragment可见且可交互时调用。
onPause()：当Fragment不可交互但可见时调用。
onStop()：当Fragment不可见时调用。
onDestroyView()：当Fragment的UI从视图结构中移除时调用。
onDestroy()：销毁Fragment时调用。
onDetach()：当Fragment和Activity解除关联时调用。
上面的方法中，只有onCreateView()在重写时不用写super方法，其他都需要。

作者：JYGod丶
链接：https://www.jianshu.com/p/11c8ced79193
來源：简书
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
*/

    // 状态选择器
    // https://blog.csdn.net/u013205623/article/details/52816751/
/*
* 3.在Xml中标签说明
selector标签，可以添加一个或多个item子标签，而相应的状态是在item标签中定义的。
定义的xml文件可以作为两种资源使用：drawable和color。

1.作为drawable资源使用时，一般和shape一样放于drawable目录下，item必须指定android:drawable属性。
2.作为color资源使用时，则放于color目录下，item必须指定android:color属性。
4.状态设置说明

android:state_enabled                **设置触摸或点击事件是否可用状态**，一般只在false时设置该属性，表示不可用状态
android:state_pressed                **设置是否按压状态**，一般在true时设置该属性，表示已按压状态，默认为false
android:state_selected               **设置是否选中状态**，true表示已选中，false表示未选中
android:state_checked:               **设置是否勾选状态**，主要用于CheckBox和RadioButton，true表示已被勾选，false表示未被勾选
android:state_checkable              **设置勾选是否可用状态**，类似state_enabled，只是state_enabled会影响触摸或点击事件，state_checkable影响勾选事件
android:state_focused                **设置是否获得焦点状态**，true表示获得焦点，默认为false，表示未获得焦点
android:state_window_focused         **设置当前窗口是否获得焦点状态**，true表示获得焦点，false表示未获得焦点，例如拉下通知栏或弹出对话框时， 当前界面就会失去焦点；另外，ListView的ListItem获得焦点时也会触发true状态，可以理解为当前窗口就是ListItem本身
android:state_activated              **设置是否被激活状态**，true表示被激活，false表示未激活，API Level 11及以上才支持，可通过代码调用控件的setActivated(boolean)方法设置是否激活该控件
android:state_hovered                **设置是否鼠标在上面滑动的状态**，true表示鼠标在上面滑动，默认为false，API Level 14及以上才支持
补充：selector标签下有两个比较有用的属性要说一下，添加了下面两个属性之后，则会在状态改变时出现淡入淡出效果，
但必须在API Level 11及以上才支持
android:exitFadeDuration             **状态改变时，旧状态消失时的淡出时间，以毫秒为单位**
android:enterFadeDuration            **状态改变时，新状态展示时的淡入时间，以毫秒为单位**
5.举例子，在按钮的背景中

<?xml version="1.0" encoding="utf-8"?>
<selector xmlns:android="http://schemas.android.com/apk/res/android">
<!-- 当前窗口失去焦点时 -->
<item android:drawable="@drawable/bg_btn_lost_window_focused" android:state_window_focused="false" />
<!-- 不可用时 -->
<item android:drawable="@drawable/bg_btn_disable" android:state_enabled="false" />
<!-- 按压时 -->
<item android:drawable="@drawable/bg_btn_pressed" android:state_pressed="true" />
<!-- 被选中时 -->
<item android:drawable="@drawable/bg_btn_selected" android:state_selected="true" />
<!-- 被激活时 -->
<item android:drawable="@drawable/bg_btn_activated" android:state_activated="true" />
<!-- 默认时 -->
<item android:drawable="@drawable/bg_btn_normal" />
</selector>
6.举例子，用于按钮的文本颜色

<?xml version="1.0" encoding="utf-8"?>
<selector xmlns:android="http://schemas.android.com/apk/res/android">
<!-- 当前窗口失去焦点时 -->
<item android:color="@android:color/black" android:state_window_focused="false" />
<!-- 不可用时 -->
<item android:color="@android:color/background_light" android:state_enabled="false" />
<!-- 按压时 -->
<item android:color="@android:color/holo_blue_light" android:state_pressed="true" />
<!-- 被选中时 -->
<item android:color="@android:color/holo_green_dark" android:state_selected="true" />
<!-- 被激活时 -->
<item android:color="@android:color/holo_green_light" android:state_activated="true" />
<!-- 默认时 -->
<item android:color="@android:color/white" />
</selector>

作者：潇湘剑雨_
链接：https://www.jianshu.com/p/7437cbf4a6a9
來源：简书
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
* */

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        Log.v("puny","FirstcodeStudyBlankFragment1 onAttach")

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.v("puny","FirstcodeStudyBlankFragment1 onCreate")

    }

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        Log.v("puny","FirstcodeStudyBlankFragment1 onCreateView")
        return inflater!!.inflate(R.layout.fragment_firstcode_study_blank_fragment1, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Log.v("puny","FirstcodeStudyBlankFragment1 onActivityCreated")
    }


    override fun onStart() {
        super.onStart()
        Log.v("puny","FirstcodeStudyBlankFragment1 onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.v("puny","FirstcodeStudyBlankFragment1 onResume")
    }
    override fun onPause() {
        super.onPause()
        Log.v("puny","FirstcodeStudyBlankFragment1 onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.v("puny","FirstcodeStudyBlankFragment1 onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.v("puny","FirstcodeStudyBlankFragment1 onDestroy")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.v("puny","FirstcodeStudyBlankFragment1 onDestroyView")
    }

    override fun onDetach() {
        super.onDetach()
        Log.v("puny","FirstcodeStudyBlankFragment1 onDetach")
    }

}// Required empty public constructor
