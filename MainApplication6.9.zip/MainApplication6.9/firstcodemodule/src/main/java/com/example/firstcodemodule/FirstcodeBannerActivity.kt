package com.example.firstcodemodule

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.util.Log
import android.view.View
import com.example.basemodule.base.BaseActivity
import android.view.ViewGroup
import android.widget.ImageView
import java.util.*
import com.example.firstcodemodule.FirstcodeBannerActivity.MyThread



// https://blog.csdn.net/u011315960/article/details/52121717
// Android实现定时器的几种方法
// 我用到的几种实现定时器的类：Handler， Timer， Thread, AlarmManager。
/*
* AlarmManager
AlarmManager是系统开放的闹钟功能，使用方式和普通的manager没有区别。

AlarmManager am = (AlarmManager)mContext.getSystemService(Context.ALARM_SERVICE);
// Schedule the alarm!
Intent intent = new Intent(XXXXX);
PendingIntent sender = PendingIntent.getBroadcast(mcontext,requestCode, intent, 0);
am.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                         firstTime, 30*1000, sender);
1
2
3
4
5
6
上面就是定时器的基本用法，先获取manager，然后定义闹钟的flag，循环时间，到指定时间发出的pendingIntent。

一般都发出的pendingIntent都是广播，我们自定义一个广播接收器，就可以通过接收这个广播，来处理自己的功能逻辑了。
* */

class FirstcodeBannerActivity : BaseActivity() {
    // 静态常量
    companion object {
        const val INDEX_KEY = "index"
        const val NAME_KEY = "NAME"
        const val FLAG_KEY = "FLAG"
        const val MESSAGE_WHAT = 1001
    }
    override fun getLayoutId(): Int {
        return R.layout.activity_firstcode_banner
    }

    override fun afterCreate(savedInstanceState: Bundle?) {
    }

    lateinit var viewPager:ViewPager
    var imageResIds:Array<Int> = arrayOf(R.drawable.icon_banner_1,R.drawable.icon_banner_2,R.drawable.icon_banner_3,R.drawable.icon_banner_4,R.drawable.icon_banner_5)
    var imageViews: MutableList<ImageView> = mutableListOf()
    lateinit var bannerIndicator: FirstcodeIndicator
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_firstcode_banner)
        setTitle("ViewPage学习")

        // imageResIds
//        Log.v("puny","ddddd:" + imageResIds.size)

        //循环遍历图片资源，然后保存到集合中
        for (i in imageResIds) {
            val imageView = ImageView(this)
            imageView.setBackgroundResource(i)
            imageViews.add(imageView)
        }

//        Log.v("puny","imageViews :" + imageViews.size)

        viewPager = findViewById<ViewPager>(R.id.firstcode_viewpage)
        bannerIndicator = findViewById<FirstcodeIndicator>(R.id.banner_indicator)
        viewPager.adapter = FirstcodeBannerPagerAdapter()


        viewPager.setOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrollStateChanged(state: Int) {
                // 开始滑动：state为1 停止：state 0
                if (state == 1) {
                    isDragingBanner = true
                } else {
                    isDragingBanner = false
                }
//                Log.v("puny", "onPageScrollStateChanged:" + state)
            }

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                // position:当前位置，positionOffset位置相对偏移百分比（0-1）；positionOffsetPixels：像素偏移
//                Log.v("puny","scroll:" + position + "   offset:" + positionOffset + "   positionOffsetPixels:"+positionOffsetPixels)
                val newPosition = position % 5
                currentIndex = position
                var tempVal = (newPosition + positionOffset + 0.5).toInt()
//                Log.v("puny","scroll:" + tempVal)
                tempVal = tempVal % 5
                bannerIndicator.setCurrentIndex(tempVal)
            }

            override fun onPageSelected(position: Int) {
                currentIndex = position
                val newPosition = position % 5
                bannerIndicator.setCurrentIndex(newPosition)
//                when (position) {
//                    0 -> bannerIndicator.setCurrentIndex(position)
//                }
            }

        })

        viewPager.setCurrentItem(10000*imageViews.size)
        currentIndex = 10000*imageViews.size

        // handler 定时器
//        handlerTimer()
//        startTimer()
        startThreadTimer()
    }


    /*
    * Thread
Thread实现定时器是创建一个子线程，在里面while循环，可以通过handler来更新UI。个人觉得Thread和Timer没区别，只是长得不一样。
*/

    // Timer
    // Timer的使用很简单，TimerTask是一个子线程，方便处理一些比较复杂耗时的功能逻辑，经常与handler结合使用。
    var timer:Timer? = Timer()
    fun startTimer() {
        timer?.schedule(object : TimerTask() {
            override fun run() {
                timerRun()
            }
        },2000,3000)
    }
    fun stopTimer()
    {
        if(timer != null){
            timer?.cancel()
            // 一定设置为null，否则定时器不会被回收
            timer = null
        }
    }



    private var currentIndex:Int = 0
    private var isDragingBanner:Boolean = false

    private lateinit var handler:Handler

    //
    fun handlerTimer()
    {
        handler = object : Handler(Looper.getMainLooper()) {
            override fun handleMessage(msg: Message?) {
                super.handleMessage(msg)
                when (msg?.what) {
                    0 -> {
                        // 移除所有的msg.what为0等消息，保证只有一个循环消息队列再跑
                        handler.removeMessages(0)
                        timerRun()
                        handler.sendEmptyMessageDelayed(0, 3000)
                    }
                    1 -> {
                        // 直接移除，定时器停止
                        handler.removeMessages(0)
                    }
                }
            }
        }
        handler.sendEmptyMessage(0)
    }

    fun timerRun() {
        if (!isDragingBanner) {
            //  // Timer的使用很简单，TimerTask是一个子线程，方便处理一些比较复杂耗时的功能逻辑，经常与handler结合使用。
            runOnUiThread(object : Runnable {
                override fun run() {
                    viewPager.setCurrentItem(currentIndex++)
                }
            })
//            viewPager.setCurrentItem(currentIndex++)
        }
//        Log.v("puny","FirstcodeBannerActivity timerRun " + Thread.currentThread().name)
    }

    override fun onDestroy() {
        stopThreadTimer()

        super.onDestroy()
        Log.v("puny","FirstcodeBannerActivity onDestroy")
    }

    inner class FirstcodeBannerPagerAdapter:PagerAdapter() {
        // 来判断显示的是否是同一张图片，这里我们将两个参数相比较返回即可。这里判断当前的View是否和对应的key关联。这里的key和instantiateItem方法的返回值一致。
        override fun isViewFromObject(view: View?, `object`: Any?): Boolean {
            return view === `object`
        }

        // 获取要滑动的控件的数量，在这里我们以滑动的广告栏为例，那么这里就应该是展示的广告图片的ImageView数量
        override fun getCount(): Int {
//            return imageResIds.size
            // 无线滚动
            return imageResIds.size * 20000
        }

        // 该方法是按需调用，默认情况先调用三次，将三个即将使用View页面添加到ViewGroup中，当你滑动到第二页View时，ViewPager会调用一次该方法将第四个View页面添加到ViewGroup中。该方法返回值作为key和对应位置的View关联起来。用于isViewFromObject方法判断当前View和key是否关联
        //返回要显示的条目内容
        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            //container  容器  相当于用来存放imageView
            //从集合中获得图片

            val newPosition = position % 5 //数组中总共有5张图片，超过数组长度时，取摸，防止下标越界
//            Log.v("puny","newPosition:" + newPosition)
            val imageView = imageViews.get(newPosition)
            //把图片添加到container中
            container.addView(imageView)
            //把图片返回给框架，用来缓存
            return imageView
        }

        // PagerAdapter只缓存三张要显示的图片，如果此时滑动到第三页时，第一页就会调用该方法去销毁相应的View。
        //销毁条目
        override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
            //object:刚才创建的对象，即要销毁的对象
//            Log.v("puny","position:" + position)
            container.removeView(`object` as View)
        }
    }

    inner class MyThread: Thread()
    {
        var stop:Boolean = false
        override fun run() {
            while (!stop) {
                // 处理功能
                timerRun()
                // 通过睡眠线程来设置定时时间
                try {
                    Thread.sleep(3000)
                } catch (e: InterruptedException) {
                    // TODO Auto-generated catch block
                    e.printStackTrace()
                }

            }
        }
    }

    var thread:MyThread? = null
    /**
     * 启动线程
     */
    private fun startThreadTimer() {
        if (thread == null) {
            thread = MyThread()
            thread?.start()
        }
    }

    /**
     * 停止线程
     */
    private fun stopThreadTimer() {
        if (thread != null) {
            thread?.stop = true
            thread = null
        }
    }
}

