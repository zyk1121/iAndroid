package com.example.basemodule.base

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import com.example.basemodule.R
import com.githang.statusbar.StatusBarCompat
import android.content.pm.PackageManager
import android.support.annotation.NonNull
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import com.example.basemodule.utils.ActivityUtils
import com.example.basemodule.utils.PermissionListener



/**
 * Created by zhangyuanke on 2018/6/3.
 */

public abstract class BaseActivity : Activity() {

    // 标题栏标题
    lateinit var titleView: TextView
    // 标题栏返回按钮
    lateinit var leftBarButton: ImageButton

    private var mPermissionListener: PermissionListener? = null
    private val CODE_REQUEST_PERMISSION = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(getLayoutId())
        initEvent()
        // 设置状态栏颜色
//        StatusBarCompat.setStatusBarColor(this, Color.WHITE)
        StatusBarCompat.setStatusBarColor(this, Color.WHITE, true)

        afterCreate(savedInstanceState)
    }

    override fun setContentView(layoutResID: Int) {
        // 隐藏系统标题栏
        /*
        * 可以看出我的Activity是继承自AppCompatActivity，所以requestWindowFeature(Window.FEATURE_NO_TITLE);这句失效了。

        解决方法有两种

        将AppCompatActivity改为Activity，此时 requestWindowFeature(Window.FEATURE_NO_TITLE);是有效的
        在onCreate()方法中加入如下代码：
        if (getSupportActionBar() != null){
            getSupportActionBar().hide();
        }

        现在就可以隐藏标题栏了。

        // 隐藏状态栏的方法
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN ,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        */
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val view = layoutInflater.inflate(com.example.basemodule.R.layout.base_activity_base, null)
        super.setContentView(view)
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.KITKAT) {
//            view.setFitsSystemWindows(true)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            // 透明状态栏
//            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

        }
        // 加载子类的Activity布局
        initDefaultView(layoutResID)
    }

    private fun initDefaultView(layoutResID: Int) {
//        networkStateView = findViewById(R.id.nsv_state_view) as NetworkStateView
        titleView = findViewById<TextView>(R.id.base_title_tv)
        leftBarButton = findViewById<ImageButton>(R.id.base_left_button)
        val container = findViewById<FrameLayout>(com.example.basemodule.R.id.base_activity_child_container)
        val childView = LayoutInflater.from(this).inflate(layoutResID, null)
        container.addView(childView, 0)
    }

    private fun initEvent() {
        leftBarButton.setOnClickListener { _: View? -> leftButtonClick() }
    }

    private fun leftButtonClick() {
        finish()
    }

    protected abstract fun getLayoutId(): Int
    protected abstract fun afterCreate(savedInstanceState: Bundle?)

    public fun setTitle(title: String) {
        titleView.setText(title)
    }

    public fun hideLeftBarButtonItem() {
        leftBarButton.visibility = View.GONE
    }

    /**
     * 申请权限
     * @param permissions 需要申请的权限(数组)
     * @param listener 权限回调接口
     */
    fun requestPermissions(permissions: Array<String>, listener: PermissionListener) {
        val activity = ActivityUtils.getTopActivity() ?: return

        mPermissionListener = listener
        var permissionList: Array<String> = arrayOf()
        for (permission in permissions) {
            //权限没有授权
            if (ContextCompat.checkSelfPermission(activity, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionList.plus(permission)
            }
        }

        if (!permissionList.isEmpty()) {
            ActivityCompat.requestPermissions(activity, permissionList, CODE_REQUEST_PERMISSION)
        } else {
            mPermissionListener?.onGranted()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            CODE_REQUEST_PERMISSION -> if (grantResults.size > 0) {
                var deniedPermissions: Array<String> = arrayOf()
                for (i in grantResults.indices) {
                    val result = grantResults[i]
                    if (result != PackageManager.PERMISSION_GRANTED) {
                        val permission = permissions[i]
                        deniedPermissions.plus(permission)
                    }
                }

                if (deniedPermissions.isEmpty()) {
                    mPermissionListener?.onGranted()
                } else {
                    mPermissionListener?.onDenied(deniedPermissions)
                }
            }

            else -> {
            }
        }
    }
}