package com.example.basemodule.utils

/**
 * Created by zhangyuanke on 2018/6/3.
 */
interface PermissionListener {
    fun onGranted()

    fun onDenied(deniedPermissions: Array<String>)
}