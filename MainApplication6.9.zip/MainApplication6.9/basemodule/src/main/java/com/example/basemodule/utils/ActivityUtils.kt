package com.example.basemodule.utils

import android.app.Activity
import android.app.Fragment
import android.app.FragmentManager
import java.util.*


/**
 * Created by zhangyuanke on 2018/6/3.
 */
public class ActivityUtils {
    companion object {
        private var mActivityStack: Stack<Activity>? = null

        /**
         * 添加一个Activity到堆栈中
         * @param activity
         */
        fun addActivity(activity: Activity) {
            if (null == mActivityStack) {
                mActivityStack = Stack()
            }
            mActivityStack!!.add(activity)
        }

        /**
         * 从堆栈中移除指定的Activity
         * @param activity
         */
        fun removeActivity(activity: Activity?) {
            if (activity != null) {
                mActivityStack!!.remove(activity)
            }
        }

        /**
         * 获取顶部的Activity
         * @return
         */
        fun getTopActivity(): Activity? {
            return if (mActivityStack!!.isEmpty()) {
                null
            } else {
                mActivityStack!!.get(mActivityStack!!.size - 1)
            }
        }

        /**
         * 结束所有的Activity，退出应用
         */
        fun removeAllActivity() {
            if (mActivityStack != null && mActivityStack!!.size > 0) {
                for (activity in mActivityStack!!) {
                    activity.finish()
                }
            }
        }

        /**
         * 将一个Fragment添加到Activity中
         * @param fragmentManager fragment管理器
         * @param fragment  需要添加的fragment
         * @param frameId  布局FrameLayout的Id
         */
        fun addFragmentToActivity(fragmentManager: FragmentManager?, fragment: Fragment?, frameId: Int) {
            if (null != fragmentManager && null != fragment) {
                val transaction = fragmentManager!!.beginTransaction()
                transaction.add(frameId, fragment)
                transaction.commit()
            }
        }

        /**
         * 将一个Fragment添加到Activity中,并添加tag标识
         * @param fragmentManager  fragment管理器
         * @param fragment  需要添加的fragment
         * @param frameId 布局FrameLayout的Id
         * @param tag  fragment的唯一tag标识
         * @param addToBackStack  是否添加到栈中，可通过返回键进行切换fragment
         */
        fun addFragmentToActivity(fragmentManager: FragmentManager?, fragment: Fragment?, frameId: Int, tag: String, addToBackStack: Boolean) {
            if (null != fragmentManager && null != fragment) {
                val transaction = fragmentManager!!.beginTransaction()
                transaction.add(frameId, fragment, tag)
                if (addToBackStack) {
                    transaction.addToBackStack(tag)
                }
                transaction.commit()
            }
        }

        /**
         * 对Fragment进行显示隐藏的切换，减少fragment的重复创建
         * @param fragmentManager fragment管理器
         * @param hideFragment  需要隐藏的Fragment
         * @param showFragment  需要显示的Fragment
         * @param frameId   布局FrameLayout的Id
         * @param tag  fragment的唯一tag标识
         */
        fun switchFragment(fragmentManager: FragmentManager?, hideFragment: Fragment, showFragment: Fragment, frameId: Int, tag: String) {
            if (fragmentManager != null) {
                val transaction = fragmentManager!!.beginTransaction()
                if (!showFragment.isAdded()) {
                    transaction.hide(hideFragment)
                            .add(frameId, showFragment, tag)
                            .commit()
                } else {
                    transaction.hide(hideFragment)
                            .show(showFragment)
                            .commit()
                }
            }
        }

        /**
         * 替换Activity中的Fragment
         * @param fragmentManager fragment管理器
         * @param fragment  需要替换到Activity的Fragment
         * @param frameId  布局FrameLayout的Id
         */
        fun replaceFragmentFromActivity(fragmentManager: FragmentManager?, fragment: Fragment?, frameId: Int) {
            if (null != fragmentManager && null != fragment) {
                val transaction = fragmentManager!!.beginTransaction()
                transaction.replace(frameId, fragment)
                transaction.commit()
            }
        }
    }
}