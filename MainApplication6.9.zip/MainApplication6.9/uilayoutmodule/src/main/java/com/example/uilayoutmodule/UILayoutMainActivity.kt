package com.example.uilayoutmodule

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.basemodule.base.BaseActivity

class UILayoutMainActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_uilayout_main)
        setTitle("Android UI")
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_uilayout_main
    }
    override fun afterCreate(savedInstanceState: Bundle?) {
    }
}
